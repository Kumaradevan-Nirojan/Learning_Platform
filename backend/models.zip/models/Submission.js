const mongoose = require('mongoose');

const submissionSchema = new mongoose.Schema({
  assignmentId: String,
  userId: String,
  answer: String,
  fileName: String,       // name of the file
  fileData: Buffer,       // PDF binary
  fileMimeType: String    // "application/pdf"
});

module.exports = mongoose.model('Submission', submissionSchema);
