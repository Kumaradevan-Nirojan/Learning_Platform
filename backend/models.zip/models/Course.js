const mongoose = require('mongoose');

const courseSchema = new mongoose.Schema({
  title: { type: String, required: true },
  description: String,
  category: {
    type: String,
    enum: [
      'Mathematics',
      'Physics',
      'Chemistry',
      'Biology',
      'Engineering',
      'Science and Technology',
      'Programming and Web Development',
      'Commerce and Management'
    ],
    required: true
  },
  syllabus: String,
  duration: String,
  startDate: Date,
  endDate: Date,
  classDays: [
    {
      day: { type: String, enum: ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'] },
      time: String // e.g., "10:00 AM - 12:00 PM"
    }
  ],
  educator: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  courseFee: Number,
  medium: { type: String }, // e.g., English, Tamil
  venue: { type: String, enum: ['Online', 'Face-to-Face'] }
});

module.exports = mongoose.model('Course', courseSchema);
