const mongoose = require('mongoose');

const educatorSchema = new mongoose.Schema({
  firstName: { type: String, required: true },
  lastName:  { type: String, required: true },
  email:     { type: String, required: true, unique: true },
  phone:     { type: String },
  address:   { type: String },
  subject:   { type: String },
  avatar:    { type: String },
  courseId: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Course' }]
}, { timestamps: true });

// 👇 Use a unique model name: "Educator"
module.exports = mongoose.models.Educator || mongoose.model('Educator', educatorSchema);
