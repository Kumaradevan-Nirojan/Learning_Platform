const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  firstName:  { type: String, required: true },
  lastName:   { type: String, required: true },
  email:      { type: String, required: true, unique: true },
  password:   { type: String, required: true },
  dob:        { type: Date, required: true },
  sex:        { type: String, enum: ['male', 'female'], required: true },
  phone:      { type: String, required: true },
  address:    { type: String, required: true },
  country:    { type: String, required: true },
  role:       { type: String, enum: ['learner', 'educator', 'coordinator'], default: 'learner' },
  avatar:     { type: String },

  // ✅ New field for multi-course assignment
  assignedCourses: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Course' }]
});

module.exports = mongoose.model('User', userSchema);
