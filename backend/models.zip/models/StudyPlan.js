const mongoose = require('mongoose');

const studyPlanSchema = new mongoose.Schema({
  course: { type: mongoose.Schema.Types.ObjectId, ref: 'Course' },
  title: String,
  content: String,
  scheduledDate: Date,
}, { timestamps: true });

module.exports = mongoose.model('StudyPlan', studyPlanSchema);
