const mongoose = require('mongoose');

const EvaluationSchema = new mongoose.Schema({
  learnerId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  educatorId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  feedback: String,
  score: Number,
  date: { type: Date, default: Date.now },
});

module.exports = mongoose.model('Evaluation', EvaluationSchema);
