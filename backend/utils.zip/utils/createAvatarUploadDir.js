const fs = require('fs');
const path = require('path');

const createAvatarUploadDir = () => {
  const dir = path.join(__dirname, '../uploads/avatars');

  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
    console.log('✅ Avatar upload directory created at:', dir);
  } else {
    console.log('⚠️ Avatar upload directory already exists:', dir);
  }
};

module.exports = createAvatarUploadDir;
