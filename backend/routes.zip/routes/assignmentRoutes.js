const express = require('express');
const router = express.Router();
const Assignment = require('../models/Assignment');
const { protect } = require('../middleware/auth');

// POST - Create assignment
router.post('/', protect, async (req, res) => {
  try {
    const { name, instructions, courseId, dueDate } = req.body;
    const assignment = new Assignment({
      name,
      instructions,
      course: courseId,
      dueDate
    });
    await assignment.save();
    res.status(201).json(assignment);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});


// GET - All assignments
router.get('/', protect, async (req, res) => {
  try {
    const assignments = await Assignment.find().populate('course', 'title').select('name instructions course dueDate createdAt');
    res.status(200).json(assignments);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// PUT - Update assignment
router.put('/:id', protect, async (req, res) => {
  try {
    const updated = await Assignment.findByIdAndUpdate(req.params.id, req.body, { new: true }).populate('course', 'title');
    res.status(200).json(updated);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// DELETE - Remove assignment
router.delete('/:id', protect, async (req, res) => {
  try {
    await Assignment.findByIdAndDelete(req.params.id);
    res.status(200).json({ message: 'Assignment deleted' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
