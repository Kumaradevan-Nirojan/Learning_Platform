const express = require('express');
const router = express.Router();
const Course = require('../models/Course');
const { protect } = require('../middleware/auth');

// 🔘 Create a new course
router.post('/', protect, async (req, res) => {
  try {
    const {
      title, description, category, syllabus, duration,
      startDate, endDate, classDays, educator,
      courseFee, medium, venue
    } = req.body;

    const course = new Course({
      title,
      description,
      category,
      syllabus,
      duration,
      startDate,
      endDate,
      classDays,
      educator,
      courseFee,
      medium,
      venue
    });

    await course.save();
    res.status(201).json(course);
  } catch (err) {
    res.status(500).json({ msg: 'Failed to create course', error: err.message });
  }
});

// 🔘 Get all courses (public)
router.get('/', async (req, res) => {
  try {
    const courses = await Course.find().populate('educator', 'firstName lastName');
    res.json(courses);
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch courses', error: err.message });
  }
});

// 🔘 Update course
router.put('/:id', protect, async (req, res) => {
  try {
    const updatedCourse = await Course.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json(updatedCourse);
  } catch (err) {
    res.status(500).json({ message: 'Failed to update course', error: err.message });
  }
});

// 🔘 Delete course
router.delete('/:id', protect, async (req, res) => {
  try {
    await Course.findByIdAndDelete(req.params.id);
    res.json({ message: 'Course deleted' });
  } catch (err) {
    res.status(500).json({ message: 'Failed to delete course', error: err.message });
  }
});

module.exports = router;
