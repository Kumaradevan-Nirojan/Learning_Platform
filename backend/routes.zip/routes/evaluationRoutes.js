const express = require('express');
const router = express.Router();
const { protect } = require('../middleware/auth');
const Evaluation = require('../models/Evaluation');

// Save Evaluation
router.post('/evaluate', protect, async (req, res) => {
  try {
    const { learnerId, feedback, score } = req.body;

    const evaluation = new Evaluation({
      learnerId,
      feedback,
      score,
      educatorId: req.user.id,
    });

    await evaluation.save();
    res.status(201).json({ message: 'Evaluation saved successfully' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
