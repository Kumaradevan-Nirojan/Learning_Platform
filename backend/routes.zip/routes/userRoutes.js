const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const multer = require('multer');
const path = require('path');

const router = express.Router();
const User = require('../models/User');
const { protect } = require('../middleware/auth');

// Multer config for avatar upload
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, 'uploads/avatars'),
  filename: (req, file, cb) => cb(null, `${Date.now()}-${file.originalname}`)
});
const uploadAvatar = multer({ storage });

// ---------------------
// POST: User Registration
// ---------------------
router.post('/register', async (req, res) => {
  const {
    firstName, lastName, email, password,
    dob, sex, phone, address, country, role
  } = req.body;

  try {
    const existing = await User.findOne({ email });
    if (existing) return res.status(400).json({ msg: 'Email already exists' });

    const hashedPassword = await bcrypt.hash(password, 10);

    const user = new User({
      firstName,
      lastName,
      email,
      password: hashedPassword,
      dob,
      sex,
      phone,
      address,
      country,
      role
    });

    await user.save();
    res.status(201).json({ msg: 'User registered successfully' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ msg: 'Server error' });
  }
});

// ---------------------
// POST: Login
// ---------------------
router.post('/login', async (req, res) => {
  const { email, password } = req.body;

  try {
    const user = await User.findOne({ email });
    if (!user) return res.status(400).json({ msg: 'Invalid credentials' });

    const match = await bcrypt.compare(password, user.password);
    if (!match) return res.status(400).json({ msg: 'Invalid credentials' });

    const token = jwt.sign({ id: user._id, role: user.role }, process.env.JWT_SECRET, {
      expiresIn: '1d'
    });

    res.json({ token, role: user.role });
  } catch (err) {
    console.error(err);
    res.status(500).json({ msg: 'Server error' });
  }
});

// ---------------------
// GET: Authenticated User Profile
// ---------------------
router.get('/me', protect, async (req, res) => {
  try {
    const user = await User.findById(req.user.id).select('-password');
    res.json(user);
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch user' });
  }
});

// ---------------------
// PUT: Update Profile (Educator Only)
// ---------------------
router.put('/update-profile', protect, uploadAvatar.single('avatar'), async (req, res) => {
  try {
    const updates = {
      firstName: req.body.firstName,
      lastName: req.body.lastName,
      dob: req.body.dob,
      sex: req.body.sex,
      phone: req.body.phone,
      address: req.body.address,
      country: req.body.country
    };

    if (req.file) {
      updates.avatar = req.file.filename;
    }

    const updated = await User.findByIdAndUpdate(req.user.id, updates, { new: true }).select('-password');

    if (!updated) return res.status(404).json({ message: 'User not found' });

    res.status(200).json(updated);
  } catch (err) {
    console.error('Profile update error:', err);
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
