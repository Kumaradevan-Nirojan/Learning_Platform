const express = require('express');
const router = express.Router();
const Enrollment = require('../models/Enrollment');
const {protect} = require('../middleware/auth');
const Submission = require('../models/Submission');
const Evaluation = require('../models/Evaluation');
const StudyPlan = require('../models/StudyPlan');

router.delete('/admin/:userId/:courseId', protect, async (req, res) => {
  try {
    const { userId, courseId } = req.params;

    // Check dependencies
    const hasQuizzes = await Evaluation.exists({ userId, courseId });
    const hasAssignments = await Submission.exists({ userId, courseId });
    const hasPlans = await StudyPlan.exists({ course: courseId, assignedTo: userId });

    if (hasQuizzes || hasAssignments || hasPlans) {
      return res.status(400).json({
        message: 'Cannot unenroll: learner has quiz/assignment/study plan progress.'
      });
    }

    const result = await Enrollment.findOneAndDelete({ userId, courseId });
    if (!result) return res.status(404).json({ message: 'Enrollment not found' });

    res.json({ message: 'Unenrolled successfully by coordinator' });
  } catch (err) {
    res.status(500).json({ message: 'Unenroll failed' });
  }
});

// Get all learners enrolled in a course
router.get('/course/:courseId', protect, async (req, res) => {
  try {
    const enrollments = await Enrollment.find({ courseId: req.params.courseId }).populate('userId');
    const learners = enrollments.map(enroll => enroll.userId);
    res.json(learners);
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch enrolled learners' });
  }
});

module.exports = router;
