const express = require('express');
const router = express.Router();
const StudyPlan = require('../models/StudyPlan');
const { protect } = require('../middleware/auth');

// POST - Create a study plan
router.post('/', protect, async (req, res) => {
  try {
    const newPlan = new StudyPlan(req.body);
    const saved = await newPlan.save();
    res.status(201).json(saved);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// GET - All study plans
router.get('/', protect, async (req, res) => {
  try {
    const plans = await StudyPlan.find().populate('course', 'title');
    res.status(200).json(plans);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
