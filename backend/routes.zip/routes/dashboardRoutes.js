// backend/routes/dashboardRoutes.js

const express = require('express');
const router = express.Router();
const User = require('../models/User');
const Course = require('../models/Course');
const protect = require('../middleware/auth');

// GET /api/dashboard/stats — Coordinator-only dashboard metrics
router.get('/stats', protect, async (req, res) => {
  try {
    // Only allow coordinator access
    if (req.user.role !== 'coordinator') {
      return res.status(403).json({ message: 'Access denied' });
    }

    // Count metrics
    const totalEducators = await User.countDocuments({ role: 'educator' });
    const totalLearners = await User.countDocuments({ role: 'learner' });
    const totalCourses = await Course.countDocuments();

    // Send summary response
    res.status(200).json({
      totalEducators,
      totalLearners,
      totalCourses,
    });
  } catch (err) {
    console.error('Dashboard stats error:', err.message);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;
