const express = require('express');
const multer = require('multer');
const path = require('path');
const router = express.Router();

// Configure multer
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, 'uploads/'),
  filename: (req, file, cb) => cb(null, `${Date.now()}-${file.originalname}`)
});
const upload = multer({ storage });

// POST endpoint for file + text
router.post('/upload', upload.single('file'), (req, res) => {
  const { assignmentId, content } = req.body;
  const fileInfo = req.file;

  console.log('Assignment ID:', assignmentId);
  console.log('Answer Text:', content);
  console.log('File:', fileInfo);

  res.status(200).json({ message: 'Submission received' });
});

module.exports = router;
