const express = require('express');
const router = express.Router();
const Quiz = require('../models/Quiz');
const { protect } = require('../middleware/auth');

// POST - Create a quiz
router.post('/', protect, async (req, res) => {
  try {
    const newQuiz = new Quiz(req.body);
    const saved = await newQuiz.save();
    res.status(201).json(saved);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// GET - All quizzes
router.get('/', protect, async (req, res) => {
  try {
    const quizzes = await Quiz.find().populate('course', 'title');
    res.status(200).json(quizzes);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// GET - Quizzes by course ID
router.get('/course/:id', protect, async (req, res) => {
  try {
    const courseId = req.params.id;
    const quizzes = await Quiz.find({ course: courseId }).populate('course', 'title');
    res.status(200).json(quizzes);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
