const express = require('express');
const multer = require('multer');
const path = require('path');
const Educator = require('../models/Educator');
const router = express.Router();


// Storage config
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, path.join(__dirname, '../uploads/avatars'));
  },
  filename: (req, file, cb) => {
    const unique = Date.now() + '-' + Math.round(Math.random() * 1e9);
    cb(null, unique + path.extname(file.originalname));
  }
});

const upload = multer({ storage });

// ✅ Get all educators
router.get('/', async (req, res) => {
  try {
    const educators = await Educator.find();
    res.status(200).json(educators);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ✅ Add educator with optional avatar
router.post('/', upload.single('avatar'), async (req, res) => {
  try {
    const { firstName, lastName, email, phone, address, subject } = req.body;

    const existing = await Educator.findOne({ email });
    if (existing) return res.status(400).json({ message: 'Educator already exists' });

    const educator = new Educator({
      firstName,
      lastName,
      email,
      phone,
      address,
      subject,
      avatar: req.file ? req.file.filename : null
    });

    await educator.save();
    res.status(201).json(educator);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

const { protect } = require('../middleware/auth'); // ✅ Import if not already
// ✅ Coordinator-only: Update educator email and avatar
router.put('/:id', protect, upload.single('avatar'), async (req, res) => {
  try {
    // ✅ Ensure only coordinator can edit
    if (req.user.role !== 'coordinator') {
      return res.status(403).json({ message: 'Access denied. Coordinator role required.' });
    }

    const updates = { email: req.body.email };
    if (req.file) {
      updates.avatar = req.file.filename;
    }

    const educator = await Educator.findByIdAndUpdate(req.params.id, updates, { new: true });
    if (!educator) {
      return res.status(404).json({ message: 'Educator not found' });
    }

    res.status(200).json(educator);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error' });
  }
});

// ✅ Delete educator
router.delete('/:id', protect, async (req, res) => {
  try {
    if (req.user.role !== 'coordinator') {
      return res.status(403).json({ message: 'Access denied' });
    }

    await Educator.findByIdAndDelete(req.params.id);
    res.json({ message: 'Educator deleted' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
