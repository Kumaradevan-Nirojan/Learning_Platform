import React, { useState } from 'react';
import axios from 'axios';

const EducatorForm = () => {
  const [form, setForm] = useState({
    firstName: '', lastName: '', email: '', password: '',
    dob: '', sex: '', phone: '', address: '', country: '', role: 'educator'
  });

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const token = localStorage.getItem('token');
      await axios.post('http://localhost:5000/api/users/register', form, {
        headers: { Authorization: token }
      });
      alert('Educator registered successfully');
      setForm({
        firstName: '', lastName: '', email: '', password: '',
        dob: '', sex: '', phone: '', address: '', country: '', role: 'educator'
      });
    } catch (err) {
      alert('Failed to register educator');
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <input name="firstName" value={form.firstName} onChange={handleChange} placeholder="First Name" required />
      <input name="lastName" value={form.lastName} onChange={handleChange} placeholder="Last Name" required />
      <input name="email" type="email" value={form.email} onChange={handleChange} placeholder="Email" required />
      <input name="password" type="password" value={form.password} onChange={handleChange} placeholder="Password" required />
      <input name="dob" type="date" value={form.dob} onChange={handleChange} required />
      <input name="sex" value={form.sex} onChange={handleChange} placeholder="Sex" required />
      <input name="phone" value={form.phone} onChange={handleChange} placeholder="Phone" required />
      <input name="address" value={form.address} onChange={handleChange} placeholder="Address" required />
      <input name="country" value={form.country} onChange={handleChange} placeholder="Country" required />
      <button type="submit">Register Educator</button>
    </form>
  );
};

export default EducatorForm;
