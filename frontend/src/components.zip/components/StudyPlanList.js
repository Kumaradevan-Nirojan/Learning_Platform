import React, { useEffect, useState } from 'react';
import axios from 'axios';

const StudyPlanList = () => {
  const [studyPlans, setStudyPlans] = useState([]);

  useEffect(() => {
    const fetchPlans = async () => {
      const token = localStorage.getItem('token');
      const res = await axios.get('http://localhost:5000/api/studyplans', {
        headers: { Authorization: token }
      });
      setStudyPlans(res.data);
    };
    fetchPlans();
  }, []);

  return (
    <div>
      <h4>Study Plans</h4>
      <ul className="list-group">
        {studyPlans.map((plan) => (
          <li key={plan._id} className="list-group-item">
            <strong>{plan.title}</strong>: {plan.description} <br />
            Course: {plan.course?.title || 'N/A'}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default StudyPlanList;
