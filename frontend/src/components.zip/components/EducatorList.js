import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';

const EducatorList = () => {
  const [educators, setEducators] = useState([]);

  useEffect(() => {
    const fetchEducators = async () => {
      const token = localStorage.getItem('token');
      try {
        const res = await axios.get('http://localhost:5000/api/users?role=educator', {
          headers: { Authorization: token }
        });
        setEducators(res.data);
      } catch (err) {
        console.error('Failed to fetch educators', err);
      }
    };
    fetchEducators();
  }, []);

  const handleDelete = async (id) => {
    if (!window.confirm('Are you sure you want to delete this educator?')) return;

    try {
      const token = localStorage.getItem('token');
      await axios.delete(`http://localhost:5000/api/educators/${id}`, {
        headers: { Authorization: token }
      });
      alert('Educator deleted');
      setEducators((prev) => prev.filter((e) => e._id !== id));
    } catch (err) {
      console.error('Delete failed', err);
      alert('Failed to delete educator');
    }
  };

  return (
    <div className="container mt-4">
      <h4 className="mb-3">Educator List</h4>
      <div className="table-responsive">
        <table className="table table-bordered table-hover">
          <thead className="table-light">
            <tr>
              <th>Name</th>
              <th>Email</th>
              <th>Phone</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {educators.map((edu) => (
              <tr key={edu._id}>
                <td>{edu.firstName} {edu.lastName}</td>
                <td>{edu.email}</td>
                <td>{edu.phone || 'N/A'}</td>
                <td>
                  <Link
                    to={`/coordinator/edit-educator/${edu._id}`}
                    className="btn btn-sm btn-warning me-2"
                  >
                    Edit
                  </Link>
                  <button
                    className="btn btn-sm btn-danger"
                    onClick={() => handleDelete(edu._id)}
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default EducatorList;
