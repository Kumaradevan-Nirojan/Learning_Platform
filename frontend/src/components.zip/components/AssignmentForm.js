// frontend/src/components/AssignmentForm.js
import React, { useEffect, useState } from 'react';
import axios from 'axios';

const AssignmentForm = ({ onSubmit, existingData }) => {
  const token = localStorage.getItem('token');

  const safeData = existingData || {};
  const [name, setName] = useState(safeData.name || '');
  const [instructions, setInstructions] = useState(safeData.instructions || '');
  const [dueDate, setDueDate] = useState(
    safeData.dueDate ? new Date(safeData.dueDate).toISOString().slice(0, 16) : ''
  );
  const [course, setCourse] = useState(safeData.course || '');
  const [courses, setCourses] = useState([]);

  useEffect(() => {
    const fetchCourses = async () => {
      try {
        const res = await axios.get('http://localhost:5000/api/courses', {
          headers: { Authorization: token }
        });
        setCourses(res.data);
      } catch (err) {
        console.error('Failed to load courses');
      }
    };
    fetchCourses();
  }, [token]);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!name || !course || !dueDate) {
      alert('Please fill in all required fields.');
      return;
    }

    const data = {
      name,
      instructions,
      course,
      dueDate: new Date(dueDate).toISOString()
    };
    onSubmit(data);

    if (!existingData) {
      setName('');
      setInstructions('');
      setCourse('');
      setDueDate('');
    }
  };

  return (
    <div>
      <h5>{existingData ? '✏️ Edit Assignment' : '➕ Create New Assignment'}</h5>
      <form onSubmit={handleSubmit}>
        <div className="mb-3">
          <label>Name <span className="text-danger">*</span></label>
          <input
            className="form-control"
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
          />
        </div>

        <div className="mb-3">
          <label>Course <span className="text-danger">*</span></label>
          <select
            className="form-select"
            value={course}
            onChange={(e) => setCourse(e.target.value)}
            required
          >
            <option value="">-- Select Course --</option>
            {courses.map((c) => (
              <option key={c._id} value={c._id}>
                {c.title}
              </option>
            ))}
          </select>
        </div>

        <div className="mb-3">
          <label>Instructions</label>
          <textarea
            className="form-control"
            value={instructions}
            onChange={(e) => setInstructions(e.target.value)}
          ></textarea>
        </div>

        <div className="mb-3">
          <label>Due Date & Time <span className="text-danger">*</span></label>
          <input
            className="form-control"
            type="datetime-local"
            value={dueDate}
            onChange={(e) => setDueDate(e.target.value)}
            required
          />
        </div>

        <button type="submit" className="btn btn-primary w-100">
          {existingData ? 'Update Assignment' : 'Create Assignment'}
        </button>
      </form>
    </div>
  );
};

export default AssignmentForm;
