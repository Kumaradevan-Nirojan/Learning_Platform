import React, { useEffect, useState } from 'react';
import axios from 'axios';

const QuizList = () => {
  const [quizzes, setQuizzes] = useState([]);

  useEffect(() => {
    const fetchQuizzes = async () => {
      const token = localStorage.getItem('token');
      const res = await axios.get('http://localhost:5000/api/quizzes', {
        headers: { Authorization: token }
      });
      setQuizzes(res.data);
    };
    fetchQuizzes();
  }, []);

  return (
    <div>
      <h4>All Quizzes</h4>
      <ul className="list-group">
        {quizzes.map((quiz) => (
          <li key={quiz._id} className="list-group-item">
            {quiz.title} (Course: {quiz.course?.title || 'N/A'})
          </li>
        ))}
      </ul>
    </div>
  );
};

export default QuizList;
