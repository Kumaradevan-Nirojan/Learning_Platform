// frontend/src/components/LearnerEvaluation.js
import React, { useState, useEffect } from 'react';
import axios from 'axios';

const LearnerEvaluation = ({ onSubmit, existingData = {} }) => {
  const [learner, setLearner] = useState(existingData.learner || '');
  const [course, setCourse] = useState(existingData.course || '');
  const [feedback, setFeedback] = useState(existingData.feedback || '');
  const [learners, setLearners] = useState([]);
  const [courses, setCourses] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const token = localStorage.getItem('token');

        const [learnerRes, courseRes] = await Promise.all([
          axios.get('http://localhost:5000/api/users?role=learner', {
            headers: { Authorization: token }
          }),
          axios.get('http://localhost:5000/api/courses', {
            headers: { Authorization: token }
          })
        ]);

        setLearners(learnerRes.data);
        setCourses(courseRes.data);
      } catch (err) {
        console.error('Error loading users or courses:', err);
      }
    };

    fetchData();
  }, []);

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit({ learner, course, feedback });
    setLearner('');
    setCourse('');
    setFeedback('');
  };

  return (
    <div className="container mt-4">
      <div className="card shadow-sm p-4">
        <h5 className="mb-3 text-center">{existingData._id ? 'Edit Evaluation' : 'Evaluate Learner'}</h5>
        <form onSubmit={handleSubmit}>
          <div className="mb-3">
            <label>Select Learner</label>
            <select
              className="form-select"
              value={learner}
              onChange={(e) => setLearner(e.target.value)}
              required
            >
              <option value="">Select a learner</option>
              {learners.map((l) => (
                <option key={l._id} value={l._id}>
                  {l.firstName} {l.lastName}
                </option>
              ))}
            </select>
          </div>
          <div className="mb-3">
            <label>Select Course</label>
            <select
              className="form-select"
              value={course}
              onChange={(e) => setCourse(e.target.value)}
              required
            >
              <option value="">Select a course</option>
              {courses.map((c) => (
                <option key={c._id} value={c._id}>
                  {c.title}
                </option>
              ))}
            </select>
          </div>
          <div className="mb-3">
            <label>Feedback</label>
            <textarea
              className="form-control"
              rows="3"
              value={feedback}
              onChange={(e) => setFeedback(e.target.value)}
              placeholder="Provide your feedback"
              required
            />
          </div>
          <button type="submit" className="btn btn-primary w-100">
            {existingData._id ? 'Update Feedback' : 'Submit Feedback'}
          </button>
        </form>
      </div>
    </div>
  );
};

export default LearnerEvaluation;
