// frontend/src/components/AssignmentSubmission.js
import React, { useState, useEffect } from 'react';
import axios from 'axios';

const AssignmentSubmission = ({ onSubmit, existingData = {} }) => {
  const [course, setCourse] = useState(existingData.course || '');
  const [assignment, setAssignment] = useState(existingData.assignment || '');
  const [file, setFile] = useState(null);
  const [courses, setCourses] = useState([]);
  const [assignments, setAssignments] = useState([]);

  useEffect(() => {
    const token = localStorage.getItem('token');

    const fetchCourses = async () => {
      try {
        const res = await axios.get('http://localhost:5000/api/courses', {
          headers: { Authorization: token }
        });
        setCourses(res.data);
      } catch (err) {
        console.error('Failed to load courses:', err);
      }
    };

    fetchCourses();
  }, []);

  useEffect(() => {
    const token = localStorage.getItem('token');

    const fetchAssignments = async () => {
      if (!course) return;
      try {
        const res = await axios.get('http://localhost:5000/api/assignments/by-course/' + course, {
          headers: { Authorization: token }
        });
        setAssignments(res.data);
      } catch (err) {
        console.error('Failed to load assignments:', err);
      }
    };

    fetchAssignments();
  }, [course]);

  const handleFileChange = (e) => {
    const selectedFile = e.target.files[0];
    if (selectedFile && selectedFile.type !== 'application/pdf') {
      alert('Only PDF files are allowed');
      e.target.value = null;
      return;
    }
    setFile(selectedFile);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!file) return alert('Please upload a PDF file.');

    const formData = new FormData();
    formData.append('assignment', assignment);
    formData.append('course', course);
    formData.append('file', file);

    onSubmit(formData);

    setCourse('');
    setAssignment('');
    setFile(null);
  };

  return (
    <div className="container mt-4">
      <div className="card shadow-sm p-4">
        <h5 className="text-center mb-3">
          {existingData._id ? 'Update Submission' : 'Submit Assignment (PDF)'}
        </h5>
        <form onSubmit={handleSubmit} encType="multipart/form-data">
          <div className="mb-3">
            <label>Select Course</label>
            <select
              className="form-select"
              value={course}
              onChange={(e) => setCourse(e.target.value)}
              required
            >
              <option value="">Select a course</option>
              {courses.map((c) => (
                <option key={c._id} value={c._id}>
                  {c.title}
                </option>
              ))}
            </select>
          </div>

          <div className="mb-3">
            <label>Select Assignment</label>
            <select
              className="form-select"
              value={assignment}
              onChange={(e) => setAssignment(e.target.value)}
              required
              disabled={!course}
            >
              <option value="">Select an assignment</option>
              {assignments.map((a) => (
                <option key={a._id} value={a._id}>
                  {a.name}
                </option>
              ))}
            </select>
          </div>

          <div className="mb-3">
            <label>Upload File (PDF Only)</label>
            <input
              type="file"
              className="form-control"
              accept="application/pdf"
              onChange={handleFileChange}
              required
            />
          </div>

          {file && (
            <div className="mb-3">
              <strong>Selected File:</strong> {file.name}
            </div>
          )}

          <button type="submit" className="btn btn-success w-100">
            {existingData._id ? 'Update Submission' : 'Submit Assignment'}
          </button>
        </form>
      </div>
    </div>
  );
};

export default AssignmentSubmission;
