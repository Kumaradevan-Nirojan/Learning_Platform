// frontend/src/components/StudentForm.js
import React, { useState } from 'react';

const StudentForm = ({ onSubmit, existingData = {} }) => {
  const [firstName, setFirstName] = useState(existingData.firstName || '');
  const [lastName, setLastName] = useState(existingData.lastName || '');
  const [email, setEmail] = useState(existingData.email || '');
  const [phone, setPhone] = useState(existingData.phone || '');
  const [address, setAddress] = useState(existingData.address || '');
  const [dob, setDob] = useState(existingData.dob || '');

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit({ firstName, lastName, email, phone, address, dob });
    setFirstName('');
    setLastName('');
    setEmail('');
    setPhone('');
    setAddress('');
    setDob('');
  };

  return (
    <div className="container mt-4">
      <div className="card shadow-sm p-4">
        <h5 className="mb-3 text-center">
          {existingData._id ? 'Edit Student' : 'Register New Student'}
        </h5>
        <form onSubmit={handleSubmit}>
          <div className="row">
            <div className="mb-3 col-md-6">
              <label>First Name</label>
              <input
                type="text"
                className="form-control"
                value={firstName}
                onChange={(e) => setFirstName(e.target.value)}
                required
              />
            </div>
            <div className="mb-3 col-md-6">
              <label>Last Name</label>
              <input
                type="text"
                className="form-control"
                value={lastName}
                onChange={(e) => setLastName(e.target.value)}
                required
              />
            </div>
          </div>
          <div className="row">
            <div className="mb-3 col-md-6">
              <label>Email</label>
              <input
                type="email"
                className="form-control"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>
            <div className="mb-3 col-md-6">
              <label>Phone</label>
              <input
                type="text"
                className="form-control"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                required
              />
            </div>
          </div>
          <div className="mb-3">
            <label>Address</label>
            <textarea
              className="form-control"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              rows="2"
              required
            />
          </div>
          <div className="mb-3">
            <label>Date of Birth</label>
            <input
              type="date"
              className="form-control"
              value={dob}
              onChange={(e) => setDob(e.target.value)}
              required
            />
          </div>
          <button type="submit" className="btn btn-success w-100">
            {existingData._id ? 'Update Student' : 'Register Student'}
          </button>
        </form>
      </div>
    </div>
  );
};

export default StudentForm;
