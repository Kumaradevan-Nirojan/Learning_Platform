import React, { useEffect, useState } from 'react';
import axios from 'axios';

const QuizListByCourse = () => {
  const [quizzes, setQuizzes] = useState([]);
  const [courses, setCourses] = useState([]);
  const [selectedCourse, setSelectedCourse] = useState('');

  useEffect(() => {
    const fetchCourses = async () => {
      try {
        const token = localStorage.getItem('token');
        const res = await axios.get('http://localhost:5000/api/courses', {
          headers: { Authorization: token }
        });
        setCourses(res.data);
      } catch (err) {
        console.error('Failed to fetch courses');
      }
    };
    fetchCourses();
  }, []);

  useEffect(() => {
    const fetchQuizzes = async () => {
      try {
        const token = localStorage.getItem('token');
        const res = await axios.get('http://localhost:5000/api/quizzes', {
          headers: { Authorization: token }
        });
        setQuizzes(res.data);
      } catch (err) {
        console.error('Failed to fetch quizzes');
      }
    };
    fetchQuizzes();
  }, []);

  const filtered = quizzes.filter((quiz) => quiz.course === selectedCourse);

  return (
    <div className="container mt-4">
      <h3>Quizzes by Course</h3>
      <select value={selectedCourse} onChange={(e) => setSelectedCourse(e.target.value)}>
        <option value="">Select Course</option>
        {courses.map((course) => (
          <option key={course._id} value={course._id}>{course.title}</option>
        ))}
      </select>

      <ul className="list-group mt-3">
        {filtered.map((quiz) => (
          <li key={quiz._id} className="list-group-item">
            {quiz.title}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default QuizListByCourse;
