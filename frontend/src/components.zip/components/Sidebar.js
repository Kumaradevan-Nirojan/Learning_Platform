// frontend/src/components/Sidebar.js
import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import 'bootstrap-icons/font/bootstrap-icons.css';

const Sidebar = () => {
  const role = localStorage.getItem('role');
  const [collapsed, setCollapsed] = useState(false);
  const [visible, setVisible] = useState(true);

  const toggleSidebar = () => setCollapsed(!collapsed);
  const toggleVisibility = () => setVisible(!visible);

  // Base navigation
  let navItems = [
    { to: '/courses', label: 'Courses', icon: 'bi-book' },
    { to: '/study-plans', label: 'Study Plans', icon: 'bi-journal-text' },
    { to: '/quizzes', label: 'Quizzes', icon: 'bi-question-circle' },
    { to: '/submissions', label: 'Assignments', icon: 'bi-file-earmark-arrow-up' },
  ];

  // Coordinator-specific
  if (role === 'coordinator') {
    navItems.push(
      { to: '/coordinator/course', label: 'Manage Courses', icon: 'bi-journal-code' },
      { to: '/student', label: 'Manage Students', icon: 'bi-people' },
      { to: '/educator', label: 'Manage Educators', icon: 'bi-person-video2' }
    );
  }

  // Educator-specific
if (role === 'educator') {
  navItems = [
    { to: '/educator', label: ' Dashboard', icon: 'bi-speedometer2' },
    { to: '/assignment', label: 'Create Assignment', icon: 'bi-file-earmark-plus' },
    ...navItems,
  ];
}


  // Learner-specific - Dashboard on top
  if (role === 'learner') {
    navItems = [
      { to: '/learner', label: 'My Dashboard', icon: 'bi-speedometer2' },
      { to: '/my-courses', label: 'My Courses', icon: 'bi-collection-play' },
      ...navItems,
    ];
  }

  if (!visible) return (
    <button className="btn btn-secondary position-fixed top-0 start-0 m-2 d-md-none" onClick={toggleVisibility}>
      <i className="bi bi-list"></i>
    </button>
  );

  return (
    <div className={`bg-light border-end vh-100 d-flex flex-column position-relative ${collapsed ? 'collapsed-sidebar' : ''}`} style={{ width: collapsed ? '70px' : '220px', transition: 'width 0.3s' }}>
      <div className="d-flex justify-content-between align-items-center p-2">
        <button className="btn btn-outline-secondary" onClick={toggleSidebar} title={collapsed ? 'Expand' : 'Collapse'}>
          <i className={`bi ${collapsed ? 'bi-chevron-double-right' : 'bi-chevron-double-left'}`}></i>
        </button>
        <button className="btn btn-outline-danger d-md-none" onClick={toggleVisibility} title="Close Sidebar">
          <i className="bi bi-x-lg"></i>
        </button>
      </div>

      <ul className="nav flex-column px-2">
        {/* Coordinator Profile Link */}
        {role === 'coordinator' && (
          <li className="nav-item">
            <NavLink
              to="/coordinator/profile"
              className={({ isActive }) =>
                'nav-link d-flex align-items-center ' + (isActive ? 'active fw-bold text-primary' : 'text-dark')
              }
              title={collapsed ? 'My Profile' : ''}
            >
              <i className="bi bi-person me-2" style={{ fontSize: '1.2rem' }}></i>
              {!collapsed && 'My Profile'}
            </NavLink>
          </li>
        )}
        {navItems.map((item, index) => (
          <li className="nav-item" key={index}>
            <NavLink
              to={item.to}
              className={({ isActive }) =>
                'nav-link d-flex align-items-center ' + (isActive ? 'active fw-bold text-primary' : 'text-dark')
              }
              title={collapsed ? item.label : ''}
            >
              <i className={`bi ${item.icon} me-2`} style={{ fontSize: '1.2rem' }}></i>
              {!collapsed && item.label}
            </NavLink>
          </li>
        ))}

        
      </ul>
    </div>
  );
};

export default Sidebar;
