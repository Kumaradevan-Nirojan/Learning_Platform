import React, { useState, useEffect } from 'react';
import { Modal, Button, Form, Image } from 'react-bootstrap';
import axios from 'axios';

const EditProfileModal = ({ show, onHide, userData, onUpdate }) => {
  const [form, setForm] = useState({
    firstName: '',
    lastName: '',
    dob: '',
    sex: '',
    phone: '',
    address: '',
    country: '',
    avatar: ''
  });

  const [preview, setPreview] = useState(null);
  const [file, setFile] = useState(null);

  useEffect(() => {
    if (userData) {
      setForm({
        firstName: userData.firstName || '',
        lastName: userData.lastName || '',
        dob: userData.dob?.slice(0, 10) || '',
        sex: userData.sex || '',
        phone: userData.phone || '',
        address: userData.address || '',
        country: userData.country || '',
        avatar: userData.avatar || 'default-avatar.png'
      });
      setPreview(`/uploads/avatars/${userData.avatar || 'default-avatar.png'}`);
    }
  }, [userData]);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleFileChange = (e) => {
    const selected = e.target.files[0];
    if (selected) {
      setFile(selected);
      setPreview(URL.createObjectURL(selected));
    }
  };

  const uploadAvatar = async () => {
    const formData = new FormData();
    formData.append('avatar', file);

    const res = await axios.post('http://localhost:5000/api/users/upload-avatar', formData, {
      headers: {
        Authorization: localStorage.getItem('token'),
        'Content-Type': 'multipart/form-data'
      }
    });

    return res.data.filename;
  };

  const handleSubmit = async () => {
    try {
      let avatarFilename = form.avatar;

      if (file) {
        avatarFilename = await uploadAvatar(); // upload and get new filename
      }

      const updatedProfile = { ...form, avatar: avatarFilename };

      const res = await axios.put('http://localhost:5000/api/users/update-profile', updatedProfile, {
        headers: { Authorization: localStorage.getItem('token') }
      });

      onUpdate(res.data); // update parent
      onHide(); // close modal
    } catch (err) {
      console.error('Update failed:', err.response?.data || err.message);
      alert('Failed to update profile');
    }
  };

  return (
    <Modal show={show} onHide={onHide} backdrop="static" centered>
      <Modal.Header closeButton>
        <Modal.Title>Edit Profile</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <div className="text-center mb-3">
          <Image
            src={preview}
            alt="avatar"
            roundedCircle
            width={100}
            height={100}
            className="border"
          />
          <Form.Group className="mt-2">
            <Form.Label>Upload New Avatar</Form.Label>
            <Form.Control type="file" accept="image/*" onChange={handleFileChange} />
          </Form.Group>
        </div>
        <Form>
          <Form.Group className="mb-2">
            <Form.Label>First Name</Form.Label>
            <Form.Control name="firstName" value={form.firstName} onChange={handleChange} />
          </Form.Group>
          <Form.Group className="mb-2">
            <Form.Label>Last Name</Form.Label>
            <Form.Control name="lastName" value={form.lastName} onChange={handleChange} />
          </Form.Group>
          <Form.Group className="mb-2">
            <Form.Label>Date of Birth</Form.Label>
            <Form.Control type="date" name="dob" value={form.dob} onChange={handleChange} />
          </Form.Group>
          <Form.Group className="mb-2">
            <Form.Label>Sex</Form.Label>
            <Form.Select name="sex" value={form.sex} onChange={handleChange}>
              <option value="">Select</option>
              <option value="Male">Male</option>
              <option value="Female">Female</option>
            </Form.Select>
          </Form.Group>
          <Form.Group className="mb-2">
            <Form.Label>Phone</Form.Label>
            <Form.Control name="phone" value={form.phone} onChange={handleChange} />
          </Form.Group>
          <Form.Group className="mb-2">
            <Form.Label>Address</Form.Label>
            <Form.Control name="address" value={form.address} onChange={handleChange} />
          </Form.Group>
          <Form.Group className="mb-2">
            <Form.Label>Country</Form.Label>
            <Form.Control name="country" value={form.country} onChange={handleChange} />
          </Form.Group>
          <Form.Group className="mb-2">
            <Form.Label>Email (Read Only)</Form.Label>
            <Form.Control value={userData?.email || ''} readOnly disabled />
          </Form.Group>
        </Form>
      </Modal.Body>
      <Modal.Footer>
        <Button variant="secondary" onClick={onHide}>Cancel</Button>
        <Button variant="primary" onClick={handleSubmit}>Save Changes</Button>
      </Modal.Footer>
    </Modal>
  );
};

export default EditProfileModal;
