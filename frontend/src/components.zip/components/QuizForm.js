// frontend/src/components/QuizForm.js
import React, { useState, useEffect } from 'react';
import axios from 'axios';

const QuizForm = ({ onSubmit, existingData = {} }) => {
  const [title, setTitle] = useState(existingData.title || '');
  const [description, setDescription] = useState(existingData.description || '');
  const [course, setCourse] = useState(existingData.course || '');
  const [courses, setCourses] = useState([]);

  useEffect(() => {
    const fetchCourses = async () => {
      try {
        const token = localStorage.getItem('token');
        const res = await axios.get('http://localhost:5000/api/courses', {
          headers: { Authorization: token }
        });
        setCourses(res.data);
      } catch (err) {
        console.error('Failed to load courses:', err);
      }
    };
    fetchCourses();
  }, []);

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit({ title, description, course });
    setTitle('');
    setDescription('');
    setCourse('');
  };

  return (
    <div className="container mt-4">
      <div className="card shadow-sm p-4">
        <h5 className="mb-3 text-center">{existingData._id ? 'Edit Quiz' : 'Create New Quiz'}</h5>
        <form onSubmit={handleSubmit}>
          <div className="mb-3">
            <label>Quiz Title</label>
            <input
              type="text"
              className="form-control"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              required
              placeholder="Enter quiz title"
            />
          </div>
          <div className="mb-3">
            <label>Description</label>
            <textarea
              className="form-control"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows="3"
              placeholder="Enter quiz instructions or notes"
              required
            />
          </div>
          <div className="mb-3">
            <label>Assign to Course</label>
            <select
              className="form-select"
              value={course}
              onChange={(e) => setCourse(e.target.value)}
              required
            >
              <option value="">Select a course</option>
              {courses.map((c) => (
                <option key={c._id} value={c._id}>
                  {c.title}
                </option>
              ))}
            </select>
          </div>
          <button type="submit" className="btn btn-primary w-100">
            {existingData._id ? 'Update Quiz' : 'Create Quiz'}
          </button>
        </form>
      </div>
    </div>
  );
};

export default QuizForm;
