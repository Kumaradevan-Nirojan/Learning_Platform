import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useParams, useNavigate } from 'react-router-dom';
import { toast, ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const EditEducator = () => {
  const { id } = useParams(); // educator id
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [avatar, setAvatar] = useState(null);
  const [existingAvatar, setExistingAvatar] = useState('');

  useEffect(() => {
    const fetchEducator = async () => {
      try {
        const token = localStorage.getItem('token');
        const res = await axios.get(`http://localhost:5000/api/educators/${id}`, {
          headers: { Authorization: token }
        });
        setEmail(res.data.email);
        setExistingAvatar(res.data.avatar);
      } catch (err) {
        toast.error('Failed to load educator details');
        navigate('/coordinator');
      }
    };
    fetchEducator();
  }, [id, navigate]);

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!email.includes('@')) {
      toast.error('Enter a valid email address');
      return;
    }

    try {
      const token = localStorage.getItem('token');
      const formData = new FormData();
      formData.append('email', email);
      if (avatar) formData.append('avatar', avatar);

      await axios.put(`http://localhost:5000/api/educators/${id}`, formData, {
        headers: { Authorization: token, 'Content-Type': 'multipart/form-data' }
      });

      toast.success('Educator updated successfully!');
      setTimeout(() => navigate('/coordinator'), 1500);
    } catch (err) {
      console.error(err);
      toast.error('Update failed');
    }
  };

  return (
    <div className="container mt-4">
      <ToastContainer />
      <div className="card p-4 shadow">
        <h4>Edit Educator</h4>
        <form onSubmit={handleSubmit} encType="multipart/form-data">
          <div className="mb-3 text-center">
            <img
              src={
                avatar
                  ? URL.createObjectURL(avatar)
                  : `/uploads/avatars/${existingAvatar || 'default-avatar.png'}`
              }
              alt="Avatar"
              className="rounded-circle"
              width="100"
              height="100"
            />
            <div className="mt-2">
              <input type="file" accept="image/*" onChange={(e) => setAvatar(e.target.files[0])} />
            </div>
          </div>

          <div className="mb-3">
            <label>Email (editable only)</label>
            <input
              type="email"
              className="form-control"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>

          <div className="text-center">
            <button type="submit" className="btn btn-primary">Update Educator</button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default EditEducator;
