// frontend/src/components/Footer.js
import React from 'react';

const Footer = () => {
  return (
    <footer className="bg-dark text-white text-center py-3 mt-4">
      <div className="container">
        <small>
          © {new Date().getFullYear()} Learning Dashboard | All Rights Reserved
        </small>
      </div>
    </footer>
  );
};

export default Footer;
