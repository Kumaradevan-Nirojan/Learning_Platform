// frontend/src/components/CourseForm.js
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams, useNavigate } from 'react-router-dom';

const CourseForm = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const isEditMode = Boolean(id);

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('');
  const [syllabus, setSyllabus] = useState('');
  const [duration, setDuration] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [classDays, setClassDays] = useState([]);
  const [educator, setEducator] = useState('');
  const [fee, setFee] = useState('');
  const [medium, setMedium] = useState('');
  const [venue, setVenue] = useState('');
  const [educators, setEducators] = useState([]);

  const categories = [
    'Mathematics', 'Physics', 'Chemistry', 'Biology',
    'Engineering', 'Science and Technology',
    'Programming and Web Development', 'Commerce and Management'
  ];
  const daysOfWeek = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

  useEffect(() => {
    const fetchEducators = async () => {
      try {
        const token = localStorage.getItem('token');
        const res = await axios.get('http://localhost:5000/api/educators', {
          headers: { Authorization: token }
        });
        setEducators(res.data);
      } catch (err) {
        console.error('Failed to fetch educators', err);
      }
    };

    const fetchCourse = async () => {
      if (!isEditMode) return;
      try {
        const token = localStorage.getItem('token');
        const res = await axios.get(`http://localhost:5000/api/courses/${id}`, {
          headers: { Authorization: token }
        });
        const data = res.data;
        setTitle(data.title || '');
        setDescription(data.description || '');
        setCategory(data.category || '');
        setSyllabus(data.syllabus || '');
        setDuration(data.duration || '');
        setStartDate(data.startDate?.slice(0, 10) || '');
        setEndDate(data.endDate?.slice(0, 10) || '');
        setClassDays(data.classDays || []);
        setEducator(data.educator || '');
        setFee(data.fee || '');
        setMedium(data.medium || '');
        setVenue(data.venue || '');
      } catch (err) {
        console.error('Failed to fetch course:', err);
      }
    };

    fetchEducators();
    fetchCourse();
  }, [id, isEditMode]);

  const handleClassDayChange = (day, time) => {
    setClassDays(prev => {
      const updated = prev.filter(d => d.day !== day);
      if (time !== null) updated.push({ day, time });
      return updated;
    });
  };

  const getClassTime = (day) => classDays.find(d => d.day === day)?.time || '';

  const handleSubmit = async (e) => {
    e.preventDefault();
    const token = localStorage.getItem('token');
    const payload = {
      title, description, category, syllabus, duration,
      startDate, endDate, classDays, educator, fee, medium, venue
    };

    try {
      if (isEditMode) {
        await axios.put(`http://localhost:5000/api/courses/${id}`, payload, {
          headers: { Authorization: token }
        });
      } else {
        await axios.post('http://localhost:5000/api/courses', payload, {
          headers: { Authorization: token }
        });
      }
      navigate('/coordinator/course');
    } catch (err) {
      console.error('Course submission failed:', err.response?.data || err.message);
    }
  };

  return (
    <div className="container mt-4">
      <div className="card shadow-sm p-4">
        <h5 className="mb-3 text-center">{isEditMode ? 'Edit Course' : 'Add New Course'}</h5>
        <form onSubmit={handleSubmit}>
          <div className="mb-3">
            <label>Course Title</label>
            <input type="text" className="form-control" value={title} onChange={(e) => setTitle(e.target.value)} required />
          </div>

          <div className="mb-3">
            <label>Description</label>
            <textarea className="form-control" value={description} onChange={(e) => setDescription(e.target.value)} required />
          </div>

          <div className="mb-3">
            <label>Category</label>
            <select className="form-select" value={category} onChange={(e) => setCategory(e.target.value)} required>
              <option value="">Select a category</option>
              {categories.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>

          <div className="mb-3">
            <label>Course Syllabus</label>
            <textarea className="form-control" value={syllabus} onChange={(e) => setSyllabus(e.target.value)} required />
          </div>

          <div className="mb-3">
            <label>Duration (e.g., 3 Months)</label>
            <input type="text" className="form-control" value={duration} onChange={(e) => setDuration(e.target.value)} required />
          </div>

          <div className="row mb-3">
            <div className="col">
              <label>Start Date</label>
              <input type="date" className="form-control" value={startDate} onChange={(e) => setStartDate(e.target.value)} required />
            </div>
            <div className="col">
              <label>End Date</label>
              <input type="date" className="form-control" value={endDate} onChange={(e) => setEndDate(e.target.value)} required />
            </div>
          </div>

          <div className="mb-3">
            <label>Class Days & Times</label>
            {daysOfWeek.map(day => (
              <div className="row mb-2" key={day}>
                <div className="col-auto d-flex align-items-center">
                  <input
                    type="checkbox"
                    checked={classDays.some(d => d.day === day)}
                    onChange={(e) => {
                      if (e.target.checked) {
                        handleClassDayChange(day, '');
                      } else {
                        handleClassDayChange(day, null);
                      }
                    }}
                  />
                  <span className="ms-2">{day}</span>
                </div>
                <div className="col">
                  <input
                    type="text"
                    className="form-control"
                    placeholder="e.g., 10:00 AM - 12:00 PM"
                    value={getClassTime(day)}
                    onChange={(e) => handleClassDayChange(day, e.target.value)}
                    disabled={!classDays.some(d => d.day === day)}
                  />
                </div>
              </div>
            ))}
          </div>

          <div className="mb-3">
            <label>Assign to Educator</label>
            <select className="form-select" value={educator} onChange={(e) => setEducator(e.target.value)} required>
              <option value="">Select an educator</option>
              {educators.map(e => (
                <option key={e._id} value={e._id}>{e.firstName} {e.lastName}</option>
              ))}
            </select>
          </div>

          <div className="mb-3">
            <label>Course Fee (LKR)</label>
            <input type="number" className="form-control" value={fee} onChange={(e) => setFee(e.target.value)} required />
          </div>

          <div className="mb-3">
            <label>Medium</label>
            <select className="form-select" value={medium} onChange={(e) => setMedium(e.target.value)} required>
              <option value="">Select medium</option>
              <option value="English">English</option>
              <option value="Tamil">Tamil</option>
              <option value="Sinhala">Sinhala</option>
            </select>
          </div>

          <div className="mb-3">
            <label>Venue</label>
            <select className="form-select" value={venue} onChange={(e) => setVenue(e.target.value)} required>
              <option value="">Select venue</option>
              <option value="Online">Online</option>
              <option value="Face-to-Face">Face-to-Face</option>
            </select>
          </div>

          <button type="submit" className="btn btn-success w-100">
            {isEditMode ? 'Update Course' : 'Create Course'}
          </button>
        </form>
      </div>
    </div>
  );
};

export default CourseForm;
