// frontend/src/pages/AssignmentPage.js
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import AssignmentForm from '../components/AssignmentForm';

const AssignmentPage = () => {
  const [assignments, setAssignments] = useState([]);
  const [editingAssignment, setEditingAssignment] = useState(null);
  const token = localStorage.getItem('token');

  const fetchAssignments = async () => {
    try {
      const res = await axios.get('http://localhost:5000/api/assignments', {
        headers: { Authorization: token }
      });
      setAssignments(res.data);
    } catch (err) {
      console.error('Failed to load assignments:', err);
    }
  };

  useEffect(() => {
    fetchAssignments();
  }, []);

  const handleCreateOrUpdate = async (data) => {
    try {
      if (editingAssignment) {
        await axios.put(`http://localhost:5000/api/assignments/${editingAssignment._id}`, data, {
          headers: { Authorization: token }
        });
      } else {
        await axios.post('http://localhost:5000/api/assignments', data, {
          headers: { Authorization: token }
        });
      }
      setEditingAssignment(null);
      fetchAssignments();
    } catch (err) {
      console.error('Failed to save assignment:', err);
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Are you sure you want to delete this assignment?')) return;
    try {
      await axios.delete(`http://localhost:5000/api/assignments/${id}`, {
        headers: { Authorization: token }
      });
      fetchAssignments();
    } catch (err) {
      console.error('Failed to delete assignment:', err);
    }
  };

  return (
    <div className="container-fluid mt-4">
      <div className="row">
        <div className="col-md-5">
          <AssignmentForm onSubmit={handleCreateOrUpdate} existingData={editingAssignment} />
        </div>
        <div className="col-md-7">
          <h5 className="mb-3">📄 Existing Assignments</h5>
          <div className="table-responsive">
            <table className="table table-bordered table-striped table-hover align-middle">
              <thead className="table-light">
                <tr>
                  <th>Name</th>
                  <th>Course</th>
                  <th>Created Date</th>
                  <th>Due Date & Time</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {assignments.map((a) => (
                  <tr key={a._id}>
                    <td>{a.name || 'N/A'}</td>
                    <td>{a.course?.title || 'N/A'}</td>
                    <td>{new Date(a.createdAt).toLocaleString()}</td>
                    <td>{new Date(a.dueDate).toLocaleString()}</td>
                    <td>
                      <button
                        className="btn btn-sm btn-outline-primary me-2"
                        onClick={() => setEditingAssignment(a)}
                      >
                        Edit
                      </button>
                      <button
                        className="btn btn-sm btn-outline-danger"
                        onClick={() => handleDelete(a._id)}
                      >
                        Delete
                      </button>
                    </td>
                  </tr>
                ))}
                {assignments.length === 0 && (
                  <tr>
                    <td colSpan="5" className="text-center text-muted">No assignments found</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AssignmentPage;
