import React from 'react';
import { Link } from 'react-router-dom';
import { color, motion } from 'framer-motion';
import './Home.css';

const Home = () => {
  return (
    <motion.div 
      className="home-container container-fluid px-3 px-md-5"
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
    >
      <header className="d-flex justify-content-between align-items-center py-3 border-bottom flex-column flex-md-row">
       
        
      </header>

      <section className="container py-5 d-flex flex-column flex-lg-row align-items-center justify-content-between">
        <div className="text-section text-center text-lg-start mb-4 mb-lg-0">
          <h1 className="fw-bold">
            For every student,<br />
            every classroom.<br />
            <span className="text-primary">Real results.</span>
          </h1>
          <p className="lead mt-3">
            We're a nonprofit with the mission to provide a free, world-class education for anyone, anywhere.
          </p>
          <div className="role mt-4 d-flex flex-column flex-sm-row justify-content-center justify-content-lg-start">
            <Link to="/learner" className="btn btn-outline-primary me-sm-2 mb-2 mb-sm-0">Learners</Link>
            <Link to="/educator" className="btn btn-outline-primary me-sm-2 mb-2 mb-sm-0">Educator</Link>
            <Link to="/coordinator" className="btn btn-outline-primary" >Coordinator</Link>
          </div>
        </div>

        <div className="image-section text-center">
          <img
            src="/images/hero-image.webp" // ✅ Replace with your image path or URL
            alt="Learner with laptop"
            className="img-fluid rounded shadow"
          />
        </div>
      </section>
    </motion.div>
  );
};

export default Home;
