// frontend/src/pages/LearnerDashboard.js
import React, { useEffect, useState } from 'react';
import axios from 'axios';

const LearnerDashboard = () => {
  const [user, setUser] = useState({});
  const token = localStorage.getItem('token');

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const res = await axios.get('http://localhost:5000/api/users/me', {
          headers: { Authorization: token }
        });
        setUser(res.data);
      } catch (err) {
        console.error('Error loading learner info:', err);
      }
    };

    fetchUser();
  }, []);

  return (
    <div className="container mt-4">
      <div className="card shadow p-4 mb-4">
        <div className="d-flex align-items-center">
          <img
            src={`http://localhost:5000/uploads/${user.avatar || 'default.png'}`}
            alt="Learner Avatar"
            className="rounded-circle me-3"
            style={{ width: '60px', height: '60px', objectFit: 'cover' }}
          />
          <div>
            <h4 className="mb-0">Welcome, {user.firstName}!</h4>
            <small className="text-muted">You are now on your Learner Dashboard</small>
          </div>
        </div>
      </div>

      <div className="row">
        <div className="col-md-6 col-lg-3 mb-3">
          <div className="card shadow-sm border-0 h-100">
            <div className="card-body text-center d-flex flex-column justify-content-between">
              <h5 className="card-title">Courses</h5>
              <a href="/courses" className="btn btn-outline-primary mt-2 w-100">View Courses</a>
            </div>
          </div>
        </div>

        <div className="col-md-6 col-lg-3 mb-3">
          <div className="card shadow-sm border-0 h-100">
            <div className="card-body text-center d-flex flex-column justify-content-between">
              <h5 className="card-title">Study Plans</h5>
              <a href="/study-plans" className="btn btn-outline-primary mt-2 w-100">View Plans</a>
            </div>
          </div>
        </div>

        <div className="col-md-6 col-lg-3 mb-3">
          <div className="card shadow-sm border-0 h-100">
            <div className="card-body text-center d-flex flex-column justify-content-between">
              <h5 className="card-title">Quizzes</h5>
              <a href="/quizzes" className="btn btn-outline-primary mt-2 w-100">Take Quizzes</a>
            </div>
          </div>
        </div>

        <div className="col-md-6 col-lg-3 mb-3">
          <div className="card shadow-sm border-0 h-100">
            <div className="card-body text-center d-flex flex-column justify-content-between">
              <h5 className="card-title">Assignments</h5>
              <a href="/submissions" className="btn btn-outline-primary mt-2 w-100">Submit/View</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LearnerDashboard;
