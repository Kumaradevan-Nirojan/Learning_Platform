
import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';

const EducatorDashboard = () => {
  const [educator, setEducator] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchEducator = async () => {
      try {
        const token = localStorage.getItem('token');
        const res = await axios.get('http://localhost:5000/api/users/me', {
          headers: { Authorization: token }
        });
        setEducator(res.data);
      } catch (err) {
        console.error('Error fetching educator:', err);
        navigate('/login');
      }
    };

    fetchEducator();
  }, [navigate]);

  const handleExportPDF = () => {
    const input = document.getElementById('educator-profile');
    html2canvas(input).then((canvas) => {
      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF();
      pdf.addImage(imgData, 'PNG', 10, 10);
      pdf.save('educator-profile.pdf');
    });
  };

  const handleEdit = () => {
    navigate('/educator/edit-profile');
  };

  return (
    <div className="container mt-4">
      <div className="card p-4 shadow" id="educator-profile">
        <h3 className="mb-4 text-center">Educator Profile</h3>

        {educator ? (
          <>
            <div className="text-center mb-4">
              <img
                src={`/uploads/avatars/${educator.avatar || 'default-avatar.png'}`}
                alt="Avatar"
                className="rounded-circle"
                width="100"
                height="100"
              />
              <p className="text-muted mt-2">Avatar</p>
            </div>

            <div className="row">
              <div className="col-md-6"><strong>Name:</strong> {educator.firstName} {educator.lastName}</div>
              <div className="col-md-6"><strong>Email:</strong> {educator.email}</div>
              <div className="col-md-6"><strong>Phone:</strong> {educator.phone || 'N/A'}</div>
              <div className="col-md-6"><strong>Date of Birth:</strong> {educator.dob?.split('T')[0] || 'N/A'}</div>
              <div className="col-md-6"><strong>Sex:</strong> {educator.sex}</div>
              <div className="col-md-6"><strong>Address:</strong> {educator.address}</div>
              <div className="col-md-6"><strong>Country:</strong> {educator.country}</div>
            </div>

            <div className="text-center mt-4">
              <button className="btn btn-primary me-2" onClick={handleEdit}>Edit Profile</button>
              <button className="btn btn-outline-secondary" onClick={handleExportPDF}>Export as PDF</button>
            </div>
          </>
        ) : (
          <p>Loading...</p>
        )}
      </div>
    </div>
  );
};

export default EducatorDashboard;
