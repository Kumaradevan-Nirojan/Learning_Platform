// frontend/src/pages/PlanPage.js
import React, { useEffect, useState } from 'react';
import axios from 'axios';

const PlanPage = () => {
  const [plans, setPlans] = useState([]);
  const token = localStorage.getItem('token');

  useEffect(() => {
    const fetchPlans = async () => {
      try {
        const res = await axios.get('http://localhost:5000/api/study-plans', {
          headers: { Authorization: token }
        });
        setPlans(res.data);
      } catch (err) {
        console.error('Error loading study plans:', err);
      }
    };
    fetchPlans();
  }, []);

  return (
    <div className="container mt-4">
      <h4 className="mb-4">📚 Study Plans</h4>
      <div className="row">
        {plans.map((plan) => (
          <div className="col-md-6 col-lg-4 mb-3" key={plan._id}>
            <div className="card h-100 shadow-sm border-0">
              <div className="card-body">
                <h5 className="card-title">{plan.topic}</h5>
                <p className="card-text">{plan.content}</p>
                <small className="text-muted">Course: {plan.course?.title || 'N/A'}</small>
              </div>
            </div>
          </div>
        ))}
        {plans.length === 0 && (
          <div className="col-12 text-center text-muted">No study plans available</div>
        )}
      </div>
    </div>
  );
};

export default PlanPage;
