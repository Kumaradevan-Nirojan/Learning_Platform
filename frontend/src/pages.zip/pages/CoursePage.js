import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import { Modal, Button } from 'react-bootstrap';
import { CSVLink } from 'react-csv';
import jsPDF from 'jspdf';
import 'jspdf-autotable';

const CoursePage = () => {
  const [courses, setCourses] = useState([]);
  const [filteredCourses, setFilteredCourses] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState('');
  const [selectedCourse, setSelectedCourse] = useState(null);
  const [showModal, setShowModal] = useState(false);
  const navigate = useNavigate();
  const token = localStorage.getItem('token');

  const categories = [
    '',
    'Mathematics',
    'Physics',
    'Chemistry',
    'Biology',
    'Engineering',
    'Science and Technology',
    'Programming and Web Development',
    'Commerce and Management'
  ];

  useEffect(() => {
    const fetchCourses = async () => {
      try {
        const res = await axios.get('/api/courses');
        setCourses(res.data);
        setFilteredCourses(res.data);
      } catch (error) {
        console.error('Failed to load courses', error);
      }
    };
    fetchCourses();
  }, []);

  const handleFilterChange = (e) => {
    const category = e.target.value;
    setSelectedCategory(category);
    if (category === '') {
      setFilteredCourses(courses);
    } else {
      setFilteredCourses(courses.filter(c => c.category === category));
    }
  };

  const handleEnroll = (courseId) => {
    if (!token) {
      alert('You must be logged in to enroll.');
      navigate('/login');
      return;
    }
    alert(`You are enrolled in course ID: ${courseId}`);
    // Future: axios.post('/api/enroll', { courseId })
  };

  const handleExportPDF = () => {
    const doc = new jsPDF();
    const tableData = filteredCourses.map(course => [
      course.title,
      course.description,
      course.category,
      course.fee || 'N/A',
      course.venue || 'N/A'
    ]);
    doc.autoTable({
      head: [['Title', 'Description', 'Category', 'Fee', 'Venue']],
      body: tableData,
    });
    doc.save('course-list.pdf');
  };

  return (
    <div className="container mt-4">
      <h2 className="mb-4 text-primary">Available Courses</h2>

      <div className="mb-3 d-flex flex-wrap justify-content-between align-items-center">
        <select className="form-select w-auto" value={selectedCategory} onChange={handleFilterChange}>
          {categories.map((cat, idx) => (
            <option key={idx} value={cat}>{cat || 'All Categories'}</option>
          ))}
        </select>

        <div className="d-flex gap-2">
          <CSVLink data={filteredCourses} filename="course-list.csv" className="btn btn-outline-secondary btn-sm">
            Export CSV
          </CSVLink>
          <button onClick={handleExportPDF} className="btn btn-outline-secondary btn-sm">
            Export PDF
          </button>
        </div>
      </div>

      <div className="row">
        {filteredCourses.map(course => (
          <div className="col-md-4 mb-3" key={course._id}>
            <div className="card shadow-sm h-100">
              <div className="card-body d-flex flex-column">
                <h5 className="card-title">{course.title}</h5>
                <p className="card-text text-muted">{course.description}</p>
                <div className="mt-auto">
                  <button
                    className="btn btn-outline-info me-2"
                    onClick={() => {
                      setSelectedCourse(course);
                      setShowModal(true);
                    }}
                  >
                    View Details
                  </button>
                  {token && (
                    <button
                      className="btn btn-outline-success"
                      onClick={() => handleEnroll(course._id)}
                    >
                      Enroll
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>
        ))}
        {filteredCourses.length === 0 && (
          <p className="text-muted">No courses available under this category.</p>
        )}
      </div>

      {/* Course Detail Modal */}
      {selectedCourse && (
        <Modal show={showModal} onHide={() => setShowModal(false)}>
          <Modal.Header closeButton>
            <Modal.Title>{selectedCourse.title}</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <p><strong>Description:</strong> {selectedCourse.description}</p>
            <p><strong>Category:</strong> {selectedCourse.category}</p>
            <p><strong>Fee:</strong> {selectedCourse.fee}</p>
            <p><strong>Duration:</strong> {selectedCourse.duration}</p>
            <p><strong>Start Date:</strong> {selectedCourse.startDate}</p>
            <p><strong>End Date:</strong> {selectedCourse.endDate}</p>
            <p><strong>Venue:</strong> {selectedCourse.venue}</p>
            <p><strong>Medium:</strong> {selectedCourse.medium}</p>
            <p><strong>Class Days:</strong> {selectedCourse.classDays?.join(', ')}</p>
          </Modal.Body>
          <Modal.Footer>
            <Button variant="secondary" onClick={() => setShowModal(false)}>Close</Button>
          </Modal.Footer>
        </Modal>
      )}
    </div>
  );
};

export default CoursePage;
