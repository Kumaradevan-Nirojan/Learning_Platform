// frontend/src/pages/Register.js
import React, { useState } from 'react';
import axios from 'axios';
import './Register.css';

const Register = () => {
  const [form, setForm] = useState({
    firstName: '', lastName: '', email: '', password: '',
    dob: '', sex: '', phone: '', address: '', country: '', role: ''
  });
  const [message, setMessage] = useState('');

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.post('http://localhost:5000/api/users/register', form);
      setMessage('Registration successful! You may now login.');
      setForm({
        firstName: '', lastName: '', email: '', password: '',
        dob: '', sex: '', phone: '', address: '', country: '', role: ''
      });
    } catch (err) {
      setMessage(err.response?.data?.msg || 'Registration failed.');
    }
  };

  return (
    <div className="container d-flex justify-content-center align-items-center" style={{ minHeight: '90vh' }}>
      <div className="card shadow p-4 w-100" style={{ maxWidth: '600px' }}>
        <h3 className="text-center mb-4">Create Your Account</h3>
        {message && (
          <div className={`alert ${message.includes('successful') ? 'alert-success' : 'alert-danger'}`}>
            {message}
          </div>
        )}
        <form onSubmit={handleSubmit}>
          <div className="row">
            <div className="col-md-6 mb-3">
              <label>First Name</label>
              <input name="firstName" value={form.firstName} onChange={handleChange} className="form-control" required />
            </div>
            <div className="col-md-6 mb-3">
              <label>Last Name</label>
              <input name="lastName" value={form.lastName} onChange={handleChange} className="form-control" required />
            </div>
          </div>
          <div className="mb-3">
            <label>Email</label>
            <input type="email" name="email" value={form.email} onChange={handleChange} className="form-control" required />
          </div>
          <div className="mb-3">
            <label>Password</label>
            <input type="password" name="password" value={form.password} onChange={handleChange} className="form-control" required />
          </div>
          <div className="row">
            <div className="col-md-6 mb-3">
              <label>Date of Birth</label>
              <input type="date" name="dob" value={form.dob} onChange={handleChange} className="form-control" required />
            </div>
            <div className="col-md-6 mb-3">
              <label>Sex</label>
              <select name="sex" value={form.sex} onChange={handleChange} className="form-select" required>
                <option value="">Select</option>
                <option value="male">Male</option>
                <option value="female">Female</option>
              </select>
            </div>
          </div>
          <div className="mb-3">
            <label>Phone</label>
            <input name="phone" value={form.phone} onChange={handleChange} className="form-control" required />
          </div>
          <div className="mb-3">
            <label>Address</label>
            <textarea name="address" value={form.address} onChange={handleChange} className="form-control" required />
          </div>
          <div className="mb-3">
            <label>Country</label>
            <input name="country" value={form.country} onChange={handleChange} className="form-control" required />
          </div>
          <div className="mb-3">
            <label>Role</label>
            <select name="role" value={form.role} onChange={handleChange} className="form-select" required>
              <option value="">Select Role</option>
              <option value="learner">Learner</option>
              <option value="educator">Educator</option>
              <option value="coordinator">Coordinator</option>
            </select>
          </div>
          <button type="submit" className="btn btn-success w-100">
            <i className="bi bi-person-plus-fill me-1"></i> Register
          </button>
        </form>
        <div className="text-center mt-3">
          Already have an account? <a href="/login">Login here</a>
        </div>
      </div>
    </div>
  );
};

export default Register;
