// frontend/src/pages/EditEducator.js
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useParams, useNavigate } from 'react-router-dom';

const EditEducator = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [form, setForm] = useState({ email: '' });
  const [avatar, setAvatar] = useState(null);
  const [educator, setEducator] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchEducator = async () => {
      try {
        const res = await axios.get(`http://localhost:5000/api/educators/${id}`);
        setEducator(res.data);
        setForm({ email: res.data.email || '' });
        setLoading(false);
      } catch (err) {
        console.error('Failed to load educator:', err);
        setLoading(false);
      }
    };

    fetchEducator();
  }, [id]);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const token = localStorage.getItem('token');
      const data = new FormData();
      data.append('email', form.email);
      if (avatar) {
        data.append('avatar', avatar);
      }

      await axios.put(`http://localhost:5000/api/educators/${id}`, data, {
        headers: {
          Authorization: token,
          'Content-Type': 'multipart/form-data'
        }
      });

      alert('Educator updated successfully!');
      navigate('/coordinator/manage-educators');
    } catch (err) {
      console.error(err);
      alert('Update failed');
    }
  };

  if (loading) return <p className="text-center mt-5">Loading...</p>;

  return (
    <div className="container mt-4">
      <div className="card p-4 shadow">
        <h3 className="mb-4 text-center">Edit Educator Email</h3>

        <form onSubmit={handleSubmit} encType="multipart/form-data">
          <div className="text-center mb-3">
            <img
              src={
                avatar
                  ? URL.createObjectURL(avatar)
                  : `/uploads/avatars/${educator?.avatar || 'default-avatar.png'}`
              }
              alt="Avatar"
              className="rounded-circle"
              width="100"
              height="100"
            />
            <div className="mt-2">
              <input type="file" accept="image/*" onChange={(e) => setAvatar(e.target.files[0])} />
            </div>
          </div>

          <div className="mb-3">
            <label>Email Address</label>
            <input
              type="email"
              name="email"
              value={form.email}
              onChange={handleChange}
              className="form-control"
              required
            />
          </div>

          <div className="text-center">
            <button type="submit" className="btn btn-primary">Save Changes</button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default EditEducator;
