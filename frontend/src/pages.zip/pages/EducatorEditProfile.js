import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import { toast, ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const EducatorEditProfile = () => {
  const [form, setForm] = useState({
    firstName: '',
    lastName: '',
    dob: '',
    sex: '',
    phone: '',
    address: '',
    country: '',
  });

  const [avatar, setAvatar] = useState(null);
  const [user, setUser] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const token = localStorage.getItem('token');
        const res = await axios.get('http://localhost:5000/api/users/me', {
          headers: { Authorization: token }
        });
        const data = res.data;
        setUser(data);
        setForm({
          firstName: data.firstName || '',
          lastName: data.lastName || '',
          dob: data.dob ? data.dob.split('T')[0] : '',
          sex: data.sex || '',
          phone: data.phone || '',
          address: data.address || '',
          country: data.country || '',
        });
      } catch (err) {
        toast.error('Session expired. Please login again.');
        navigate('/login');
      }
    };

    fetchUser();
  }, [navigate]);

  const handleChange = (e) => {
    const { name, value } = e.target;

    // Phone validation: allow + and digits only
    if (name === 'phone' && value && !/^\+?\d{0,15}$/.test(value)) return;

    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    // ✅ Basic phone number validation
    if (!/^\+\d{9,15}$/.test(form.phone)) {
      toast.error('Phone number must include country code (e.g., +94123456789)');
      return;
    }

    try {
      const token = localStorage.getItem('token');
      const formData = new FormData();
      Object.entries(form).forEach(([key, value]) => formData.append(key, value));
      if (avatar) formData.append('avatar', avatar);

      const res = await axios.put('http://localhost:5000/api/users/update-profile', formData, {
        headers: { Authorization: token, 'Content-Type': 'multipart/form-data' }
      });

      localStorage.setItem('user', JSON.stringify(res.data));
      toast.success('Profile updated successfully!');
      setTimeout(() => navigate('/educator'), 1500);
    } catch (err) {
      console.error('Failed to update profile', err);
      toast.error('Profile update failed');
    }
  };

  return (
    <div className="container mt-4">
      <ToastContainer />
      <div className="card p-4 shadow">
        <h3 className="mb-4">Edit Profile</h3>
        <form onSubmit={handleSubmit} encType="multipart/form-data">
          <div className="mb-3 text-center">
            <img
              src={avatar ? URL.createObjectURL(avatar) : `/uploads/avatars/${user?.avatar || 'default-avatar.png'}`}
              alt="Avatar"
              className="rounded-circle"
              width="100"
              height="100"
            />
            <div className="mt-2">
              <input type="file" accept="image/*" onChange={(e) => setAvatar(e.target.files[0])} />
            </div>
          </div>

          <div className="row">
            <div className="col-md-6 mb-3">
              <label>First Name</label>
              <input type="text" className="form-control" name="firstName" value={form.firstName} onChange={handleChange} required />
            </div>
            <div className="col-md-6 mb-3">
              <label>Last Name</label>
              <input type="text" className="form-control" name="lastName" value={form.lastName} onChange={handleChange} required />
            </div>
            <div className="col-md-6 mb-3">
              <label>Date of Birth</label>
              <input type="date" className="form-control" name="dob" value={form.dob} onChange={handleChange} />
            </div>
            <div className="col-md-6 mb-3">
              <label>Sex</label>
              <select className="form-control" name="sex" value={form.sex} onChange={handleChange}>
                <option value="">Select</option>
                <option value="Male">Male</option>
                <option value="Female">Female</option>
              </select>
            </div>
            <div className="col-md-6 mb-3">
              <label>Phone <small>(e.g. +94123456789)</small></label>
              <input
                type="text"
                className="form-control"
                name="phone"
                value={form.phone}
                onChange={handleChange}
                required
              />
            </div>
            <div className="col-md-6 mb-3">
              <label>Address</label>
              <input type="text" className="form-control" name="address" value={form.address} onChange={handleChange} />
            </div>
            <div className="col-md-6 mb-3">
              <label>Country</label>
              <input type="text" className="form-control" name="country" value={form.country} onChange={handleChange} />
            </div>
          </div>

          <div className="text-center mt-3">
            <button type="submit" className="btn btn-success">Update Profile</button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default EducatorEditProfile;
