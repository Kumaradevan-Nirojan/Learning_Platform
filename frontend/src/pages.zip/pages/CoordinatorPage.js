import React, { useState, useEffect } from 'react';
import axios from 'axios';
import EditProfileModal from '../components/EditProfileModal';

const CoordinatorPage = () => {
  const [coordinator, setCoordinator] = useState(null);
  const [editing, setEditing] = useState(false);

  useEffect(() => {
    const fetchCoordinator = async () => {
      try {
        const token = localStorage.getItem('token');
        const res = await axios.get('http://localhost:5000/api/users/me', {
          headers: { Authorization: token }
        });
        setCoordinator(res.data);
      } catch (err) {
        console.error('Failed to load coordinator profile:', err.response?.data || err.message);
      }
    };

    fetchCoordinator();
  }, []);

  if (!coordinator) {
    return <div className="text-center py-5">Loading coordinator profile...</div>;
  }

  return (
    <div className="container mt-4">
      <div className="card shadow p-4">
        <h4 className="mb-4">Coordinator Profile</h4>
        <div className="row">
          <div className="col-md-4 text-center">
            <img
              src={
                coordinator.avatar && coordinator.avatar !== 'default-avatar.png'
                  ? `http://localhost:5000/uploads/avatars/${coordinator.avatar}`
                  : 'https://via.placeholder.com/150'
              }
              alt="Avatar"
              className="img-fluid rounded-circle mb-3"
              style={{ width: '150px', height: '150px', objectFit: 'cover' }}
            />
          </div>
          <div className="col-md-8">
            <p><strong>Name:</strong> {coordinator.firstName} {coordinator.lastName}</p>
            <p><strong>Email:</strong> {coordinator.email}</p>
            <p><strong>Phone:</strong> {coordinator.phone}</p>
            <p><strong>Date of Birth:</strong> {coordinator.dob?.slice(0, 10)}</p>
            <p><strong>Sex:</strong> {coordinator.sex}</p>
            <p><strong>Address:</strong> {coordinator.address}</p>
            <p><strong>Country:</strong> {coordinator.country}</p>
            <button className="btn btn-outline-primary" onClick={() => setEditing(true)}>
              Edit Profile
            </button>
          </div>
        </div>
      </div>

      {editing && (
        <EditProfileModal
          show={editing}
          onHide={() => setEditing(false)}
          userData={coordinator}
          onUpdate={(updated) => {
            setCoordinator(updated);
            setEditing(false);
          }}
        />
      )}
    </div>
  );
};

export default CoordinatorPage;
