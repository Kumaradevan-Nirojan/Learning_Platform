// frontend/src/pages/ViewEducator.js
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useParams, useNavigate } from 'react-router-dom';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';

const ViewEducator = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [educator, setEducator] = useState(null);
  const [user, setUser] = useState(null);

  useEffect(() => {
    const userData = localStorage.getItem('user');
    if (userData) {
      setUser(JSON.parse(userData));
    }

    const fetchEducator = async () => {
      try {
        const res = await axios.get(`http://localhost:5000/api/educators/${id}`);
        setEducator(res.data);
      } catch (err) {
        console.error('Failed to load educator:', err);
      }
    };

    fetchEducator();
  }, [id]);

  const handleExportPDF = () => {
    const input = document.getElementById('educator-profile');
    html2canvas(input).then((canvas) => {
      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF();
      pdf.addImage(imgData, 'PNG', 10, 10);
      pdf.save('educator-profile.pdf');
    });
  };

  const handleEdit = () => {
    navigate(`/coordinator/edit-educator/${educator._id}`);
  };

  return (
    <div className="container mt-4">
      <div className="card p-4 shadow" id="educator-profile">
        <h3 className="mb-4 text-center">Educator Profile</h3>

        {educator ? (
          <>
            <div className="text-center mb-3">
              <img
                src={`/uploads/avatars/${educator.avatar || 'default-avatar.png'}`}
                alt="Avatar"
                className="rounded-circle"
                width="100"
                height="100"
              />
              <p className="text-muted mt-2">Avatar</p>
            </div>

            <ul className="nav nav-tabs mb-3" id="educatorTabs" role="tablist">
              <li className="nav-item">
                <button className="nav-link active" id="info-tab" data-bs-toggle="tab" data-bs-target="#info" type="button" role="tab">
                  Basic Info
                </button>
              </li>
              <li className="nav-item">
                <button className="nav-link" id="courses-tab" data-bs-toggle="tab" data-bs-target="#courses" type="button" role="tab">
                  Courses
                </button>
              </li>
            </ul>

            <div className="tab-content" id="educatorTabsContent">
              <div className="tab-pane fade show active" id="info" role="tabpanel">
                <div className="row">
                  <div className="col-md-6"><strong>Name:</strong> {educator.firstName} {educator.lastName}</div>
                  <div className="col-md-6"><strong>Email:</strong> {educator.email}</div>
                  <div className="col-md-6"><strong>Phone:</strong> {educator.phone || 'N/A'}</div>
                  <div className="col-md-6"><strong>Subject:</strong> {educator.subject || 'N/A'}</div>
                  <div className="col-md-6"><strong>Address:</strong> {educator.address || 'N/A'}</div>
                </div>
              </div>
              <div className="tab-pane fade" id="courses" role="tabpanel">
                <ul>
                  {educator.courseId?.length > 0
                    ? educator.courseId.map((c) => <li key={c._id}>{c.title}</li>)
                    : <li>No courses assigned</li>}
                </ul>
              </div>
            </div>

            <div className="text-center mt-4">
              {user?.role === 'coordinator' && (
                <button className="btn btn-outline-warning me-2" onClick={handleEdit}>Edit Email</button>
              )}
              <button className="btn btn-outline-secondary" onClick={handleExportPDF}>Export as PDF</button>
            </div>
          </>
        ) : (
          <p>Loading...</p>
        )}
      </div>
    </div>
  );
};

export default ViewEducator;
