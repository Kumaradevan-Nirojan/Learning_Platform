// frontend/src/pages/UnenrollLearner.js
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select } from '@/components/ui/select';
import { Table } from '@/components/ui/table';
import { UserX } from 'lucide-react';

const UnenrollLearner = () => {
  const [courses, setCourses] = useState([]);
  const [selectedCourse, setSelectedCourse] = useState(null);
  const [enrolledLearners, setEnrolledLearners] = useState([]);
  const token = localStorage.getItem('token');

  useEffect(() => {
    const fetchCourses = async () => {
      try {
        const res = await axios.get('/api/courses', {
          headers: { Authorization: token }
        });
        setCourses(res.data);
      } catch (err) {
        console.error('Failed to fetch courses');
      }
    };
    fetchCourses();
  }, [token]);

  const fetchEnrolledLearners = async (courseId) => {
    try {
      const res = await axios.get(`/api/enroll/course/${courseId}`, {
        headers: { Authorization: token }
      });
      setEnrolledLearners(res.data);
      setSelectedCourse(courseId);
    } catch (err) {
      console.error('Failed to fetch learners');
    }
  };

  const handleUnenroll = async (userId) => {
    try {
      const res = await axios.delete(`/api/enroll/admin/${userId}/${selectedCourse}`, {
        headers: { Authorization: token }
      });
      alert(res.data.message);
      setEnrolledLearners(prev => prev.filter(u => u._id !== userId));
    } catch (err) {
      alert(err.response?.data?.message || 'Unenroll failed');
    }
  };

  return (
    <div className="p-4">
      <h2 className="text-xl font-bold mb-4">📚 Coordinator Panel - Unenroll Learners</h2>

      <div className="mb-4">
        <label htmlFor="courseSelect" className="font-medium mb-1 block">Select a Course</label>
        <select
          id="courseSelect"
          className="border rounded-md px-4 py-2 w-full"
          onChange={(e) => fetchEnrolledLearners(e.target.value)}
        >
          <option value="">-- Select a Course --</option>
          {courses.map(course => (
            <option key={course._id} value={course._id}>{course.title}</option>
          ))}
        </select>
      </div>

      {enrolledLearners.length > 0 && (
        <Card className="overflow-x-auto">
          <table className="min-w-full text-sm">
            <thead className="bg-gray-100">
              <tr>
                <th className="p-2 text-left font-semibold">👤 Learner</th>
                <th className="p-2 text-left font-semibold">✉️ Email</th>
                <th className="p-2 text-left font-semibold">Action</th>
              </tr>
            </thead>
            <tbody>
              {enrolledLearners.map(learner => (
                <tr key={learner._id} className="border-t">
                  <td className="p-2">{learner.firstName} {learner.lastName}</td>
                  <td className="p-2">{learner.email}</td>
                  <td className="p-2">
                    <Button variant="destructive" size="sm" onClick={() => handleUnenroll(learner._id)}>
                      <UserX className="w-4 h-4 mr-1" /> Unenroll
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      )}
    </div>
  );
};

export default UnenrollLearner;
