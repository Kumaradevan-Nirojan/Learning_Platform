import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const CoursePage = () => {
  const [courses, setCourses] = useState([]);
  const navigate = useNavigate();
  const token = localStorage.getItem('token');

  useEffect(() => {
    const fetchCourses = async () => {
      try {
        const res = await axios.get('/api/courses');
        setCourses(res.data);
      } catch (error) {
        console.error('Failed to load courses', error);
      }
    };
    fetchCourses();
  }, []);

  const handleEnroll = (courseId) => {
    if (!token) {
      alert('You must be logged in to enroll.');
      navigate('/login');
      return;
    }
    alert(`You are enrolled in course ID: ${courseId}`);
    // You can add axios.post('/api/enroll', { courseId }) here in future
  };

  return (
    <div className="container mt-4">
      <h2 className="mb-4 text-primary">Available Courses</h2>
      <div className="row">
        {courses.map(course => (
          <div className="col-md-4 mb-3" key={course._id}>
            <div className="card shadow-sm h-100">
              <div className="card-body d-flex flex-column">
                <h5 className="card-title">{course.title}</h5>
                <p className="card-text text-muted">{course.description}</p>
                <button
                  className="btn btn-outline-success mt-auto"
                  onClick={() => handleEnroll(course._id)}
                >
                  Enroll Now
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default CoursePage;
