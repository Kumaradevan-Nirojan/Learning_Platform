// frontend/src/pages/MyCourses.js
import React, { useEffect, useState } from 'react';
import axios from 'axios';

const MyCourses = () => {
  const [myCourses, setMyCourses] = useState([]);
  const token = localStorage.getItem('token');
  const role = localStorage.getItem('role');

  useEffect(() => {
    const fetchMyCourses = async () => {
      try {
        const res = await axios.get('/api/enroll/details', {
          headers: { Authorization: token }
        });
        setMyCourses(res.data);
      } catch (err) {
        console.error('Error fetching enrolled courses', err);
      }
    };
    fetchMyCourses();
  }, [token]);

  const handleUnenroll = async (courseId) => {
    try {
      const res = await axios.delete(`/api/enroll/${courseId}`, {
        headers: { Authorization: token }
      });
      alert(res.data.message);
      setMyCourses(prev => prev.filter(c => c._id !== courseId));
    } catch (err) {
      alert(err.response?.data?.message || 'Unenroll failed');
    }
  };

  const within24Hours = (dateString) => {
    const enrolledAt = new Date(dateString);
    const now = new Date();
    const diffHours = (now - enrolledAt) / (1000 * 60 * 60);
    return diffHours <= 24;
  };

  return (
    <div className="container mt-4">
      <h2 className="mb-4 text-success">My Enrolled Courses</h2>
      <div className="row">
        {myCourses.length === 0 ? (
          <p>You have not enrolled in any courses yet.</p>
        ) : (
          myCourses.map(course => (
            <div className="col-md-4 mb-3" key={course._id}>
              <div className="card h-100 shadow-sm">
                <div className="card-body d-flex flex-column">
                  <h5 className="card-title">{course.title}</h5>
                  <p className="card-text text-muted">{course.description}</p>
                  {role === 'learner' && within24Hours(course.enrolledAt) && (
                    <button
                      className="btn btn-danger mt-auto"
                      onClick={() => handleUnenroll(course._id)}
                    >
                      Unenroll
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default MyCourses;
