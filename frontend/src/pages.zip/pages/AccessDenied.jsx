import React from 'react';
import { Link } from 'react-router-dom';

const AccessDenied = () => {
  return (
    <div className="container text-center my-5">
      <h2 className="text-danger">403 - Access Denied</h2>
      <p>You do not have permission to access this page.</p>
      <Link to="/" className="btn btn-primary mt-3">Back to Home</Link>
    </div>
  );
};

export default AccessDenied;
