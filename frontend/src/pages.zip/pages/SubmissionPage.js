// frontend/src/pages/SubmissionPage.js
import React, { useEffect, useState } from 'react';
import axios from 'axios';

const SubmissionPage = () => {
  const [submissions, setSubmissions] = useState([]);
  const token = localStorage.getItem('token');

  useEffect(() => {
    const fetchSubmissions = async () => {
      try {
        const res = await axios.get('http://localhost:5000/api/submissions', {
          headers: { Authorization: token }
        });
        setSubmissions(res.data);
      } catch (err) {
        console.error('Failed to load submissions:', err);
      }
    };

    fetchSubmissions();
  }, []);

  return (
    <div className="container-fluid mt-4">
      <h4 className="mb-4">📥 Learner Assignment Submissions</h4>
      <div className="table-responsive">
        <table className="table table-bordered table-hover align-middle">
          <thead className="table-light">
            <tr>
              <th>Learner</th>
              <th>Course</th>
              <th>Assignment</th>
              <th>PDF File</th>
              <th>Submitted On</th>
            </tr>
          </thead>
          <tbody>
            {submissions.map((sub) => (
              <tr key={sub._id}>
                <td>{sub.user?.firstName} {sub.user?.lastName}</td>
                <td>{sub.course?.title || 'N/A'}</td>
                <td>{sub.assignment?.name || 'N/A'}</td>
                <td>
                  {sub.file ? (
                    <a
                      href={`http://localhost:5000/uploads/${sub.file}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="btn btn-sm btn-outline-primary"
                    >
                      Download
                    </a>
                  ) : (
                    <span className="text-muted">No file</span>
                  )}
                </td>
                <td>{new Date(sub.createdAt).toLocaleString()}</td>
              </tr>
            ))}
            {submissions.length === 0 && (
              <tr>
                <td colSpan="5" className="text-center text-muted">No submissions found</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default SubmissionPage;
