// frontend/src/pages/CoordinatorCoursePage.js
import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

const CoordinatorCoursePage = () => {
  const [courses, setCourses] = useState([]);
  const navigate = useNavigate();
  const token = localStorage.getItem('token');

  const fetchCourses = async () => {
    try {
      const res = await axios.get('http://localhost:5000/api/courses', {
        headers: { Authorization: token }
      });
      setCourses(res.data);
    } catch (err) {
      console.error('Failed to fetch courses:', err);
    }
  };

  useEffect(() => {
    fetchCourses();
  }, []);

  const handleEdit = (id) => {
    navigate(`/coordinator/course/edit/${id}`);
  };

  const handleDelete = async (id) => {
    if (window.confirm('Are you sure you want to delete this course?')) {
      try {
        await axios.delete(`http://localhost:5000/api/courses/${id}`, {
          headers: { Authorization: token }
        });
        fetchCourses();
      } catch (err) {
        console.error('Delete failed:', err);
      }
    }
  };

  return (
    <div className="container mt-4">
      <div className="d-flex justify-content-between align-items-center mb-3">
        <h4>Manage Courses</h4>
        <button className="btn btn-success" onClick={() => navigate('/coordinator/course/create')}>
          <i className="bi bi-plus-circle me-1"></i> Add Course
        </button>
      </div>

      <div className="table-responsive">
        <table className="table table-bordered">
          <thead className="table-light">
            <tr>
              <th>Title</th>
              <th>Category</th>
              <th>Duration</th>
              <th>Start Date</th>
              <th>End Date</th>
              <th>Fee (LKR)</th>
              <th>Medium</th>
              <th>Venue</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {courses.map(course => (
              <tr key={course._id}>
                <td>{course.title}</td>
                <td>{course.category}</td>
                <td>{course.duration}</td>
                <td>{course.startDate?.slice(0,10)}</td>
                <td>{course.endDate?.slice(0,10)}</td>
                <td>{course.fee}</td>
                <td>{course.medium}</td>
                <td>{course.venue}</td>
                <td>
                  <button className="btn btn-sm btn-outline-primary me-2" onClick={() => handleEdit(course._id)}>Edit</button>
                  <button className="btn btn-sm btn-outline-danger" onClick={() => handleDelete(course._id)}>Delete</button>
                </td>
              </tr>
            ))}
            {courses.length === 0 && (
              <tr><td colSpan="9" className="text-center text-muted">No courses found</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default CoordinatorCoursePage;
