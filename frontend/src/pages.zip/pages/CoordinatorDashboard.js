import React, { useEffect, useState, useRef } from 'react';
import axios from 'axios';
import { Pie, Bar } from 'react-chartjs-2';
import { Chart, ArcElement, BarElement, CategoryScale, LinearScale } from 'chart.js';
import { useReactToPrint } from 'react-to-print';

Chart.register(ArcElement, BarElement, CategoryScale, LinearScale);

const CoordinatorDashboard = () => {
  const [stats, setStats] = useState({
    totalEducators: 0,
    totalLearners: 0,
    totalCourses: 0,
  });
  const [educators, setEducators] = useState([]);
  const componentRef = useRef();

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const token = localStorage.getItem('token');
        const res = await axios.get('http://localhost:5000/api/dashboard/stats', {
          headers: { Authorization: token },
        });
        setStats(res.data);
      } catch (err) {
        console.error('Error fetching dashboard stats:', err);
      }
    };

    const fetchEducators = async () => {
      try {
        const token = localStorage.getItem('token');
        const res = await axios.get('http://localhost:5000/api/users/educators', {
          headers: { Authorization: token },
        });
        setEducators(res.data);
      } catch (err) {
        console.error('Error fetching educators:', err);
      }
    };

    fetchStats();
    fetchEducators();
  }, []);

  const chartData = {
    labels: ['Educators', 'Learners', 'Courses'],
    datasets: [
      {
        label: 'Total Count',
        data: [stats.totalEducators, stats.totalLearners, stats.totalCourses],
        backgroundColor: ['#007bff', '#28a745', '#17a2b8'],
      },
    ],
  };

  const handlePrint = useReactToPrint({
    content: () => componentRef.current,
  });

  return (
    <div className="container mt-4" ref={componentRef}>
      <h2 className="mb-4 text-center">Coordinator Dashboard</h2>

      <div className="row g-4 mb-4">
        <div className="col-md-4">
          <div className="card shadow border-primary">
            <div className="card-body text-center">
              <h5 className="card-title">Total Educators</h5>
              <h3 className="text-primary">{stats.totalEducators}</h3>
            </div>
          </div>
        </div>

        <div className="col-md-4">
          <div className="card shadow border-success">
            <div className="card-body text-center">
              <h5 className="card-title">Total Learners</h5>
              <h3 className="text-success">{stats.totalLearners}</h3>
            </div>
          </div>
        </div>

        <div className="col-md-4">
          <div className="card shadow border-info">
            <div className="card-body text-center">
              <h5 className="card-title">Total Courses</h5>
              <h3 className="text-info">{stats.totalCourses}</h3>
            </div>
          </div>
        </div>
      </div>

      <div className="row mb-5">
        <div className="col-md-6">
          <Bar data={chartData} />
        </div>
        <div className="col-md-6">
          <Pie data={chartData} />
        </div>
      </div>

      <div className="d-flex justify-content-between align-items-center mb-3">
        <h4>Educator List</h4>
        <button className="btn btn-outline-secondary" onClick={handlePrint}>
          Export as PDF
        </button>
      </div>

      <table className="table table-bordered table-striped">
        <thead>
          <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Address</th>
          </tr>
        </thead>
        <tbody>
          {educators.map((edu) => (
            <tr key={edu._id}>
              <td>{edu.firstName} {edu.lastName}</td>
              <td>{edu.email}</td>
              <td>{edu.phone}</td>
              <td>{edu.address}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default CoordinatorDashboard;
