import React from 'react';
import { motion } from 'framer-motion';

const About = () => {
  return (
    <motion.div 
      className="container py-5 px-3 px-md-5"
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
    >
      <h2 className="text-center mb-4">About Us</h2>
      <p className="lead text-center">
        We are committed to transforming learning experiences through modern educational technologies.
      </p>
      <p className="text-center">
        Our platform supports learners, educators, and coordinators with a unified dashboard.
        Whether you're a student seeking quality content or an educator managing assignments and evaluations, our Learning Dashboard simplifies and centralizes the entire journey.
      </p>
    </motion.div>
  );
};

export default About;
