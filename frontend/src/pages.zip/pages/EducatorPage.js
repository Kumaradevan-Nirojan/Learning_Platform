import React, { useEffect, useState } from 'react';
import axios from 'axios';

const EducatorPage = () => {
  const [educators, setEducators] = useState([]);
  const [courses, setCourses] = useState([]);
  const [editingId, setEditingId] = useState(null);
  const [selectedCourses, setSelectedCourses] = useState([]);

  useEffect(() => {
    fetchEducators();
    fetchCourses();
  }, []);

  const fetchEducators = async () => {
    const token = localStorage.getItem('token');
    try {
      const res = await axios.get('http://localhost:5000/api/users/educators', {
        headers: { Authorization: token },
      });
      setEducators(res.data);
    } catch (err) {
      console.error('Error fetching educators:', err);
    }
  };

  const fetchCourses = async () => {
    const token = localStorage.getItem('token');
    try {
      const res = await axios.get('http://localhost:5000/api/courses', {
        headers: { Authorization: token },
      });
      setCourses(res.data);
    } catch (err) {
      console.error('Error fetching courses:', err);
    }
  };

  const handleEdit = (educator) => {
    setEditingId(educator._id);
    const ids = educator.courseId?.map((course) =>
      typeof course === 'object' ? course._id : course
    );
    setSelectedCourses(ids || []);
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Are you sure you want to delete this educator?')) return;
    const token = localStorage.getItem('token');
    try {
      await axios.delete(`http://localhost:5000/api/users/${id}`, {
        headers: { Authorization: token },
      });
      fetchEducators();
    } catch (err) {
      console.error('Error deleting educator:', err);
    }
  };

  const handleCheckboxChange = (courseId) => {
    setSelectedCourses((prev) =>
      prev.includes(courseId)
        ? prev.filter((id) => id !== courseId)
        : [...prev, courseId]
    );
  };

  const handleUpdate = async (id) => {
    const token = localStorage.getItem('token');
    try {
      await axios.put(
        `http://localhost:5000/api/users/educators/${id}/assign-courses`,
        { courseIds: selectedCourses },
        { headers: { Authorization: token } }
      );
      setEditingId(null);
      fetchEducators();
    } catch (err) {
      console.error('Error updating courses:', err);
    }
  };

  return (
    <div className="container mt-4">
      <h3>👨‍🏫 Educator Profile</h3>
      <table className="table table-striped mt-3">
        <thead>
          <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Assigned Courses</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {educators.map((e) => (
            <tr key={e._id}>
              <td>{e.firstName} {e.lastName}</td>
              <td>{e.email}</td>
              <td>{e.phone}</td>
              <td>
                {editingId === e._id ? (
                  <>
                    {courses.map((course) => (
                      <div key={course._id}>
                        <label>
                          <input
                            type="checkbox"
                            checked={selectedCourses.includes(course._id)}
                            onChange={() => handleCheckboxChange(course._id)}
                          />
                          &nbsp;{course.title}
                        </label>
                      </div>
                    ))}
                    <button className="btn btn-sm btn-success mt-2" onClick={() => handleUpdate(e._id)}>
                      Save
                    </button>
                  </>
                ) : (
                  <>
                    {e.courseId?.length > 0
                      ? e.courseId.map((c) => (typeof c === 'object' ? c.title : '')).join(', ')
                      : 'No courses assigned'}
                  </>
                )}
              </td>
              <td>
                {editingId === e._id ? null : (
                  <>
                    <button className="btn btn-sm btn-warning me-2" onClick={() => handleEdit(e)}>Edit</button>
                    <button className="btn btn-sm btn-danger" onClick={() => handleDelete(e._id)}>Delete</button>
                  </>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default EducatorPage;
