// frontend/src/pages/Dashboard.js
import React, { useEffect, useState } from 'react';
import axios from 'axios';

const Dashboard = () => {
  const [user, setUser] = useState({});
  const token = localStorage.getItem('token');

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const res = await axios.get('http://localhost:5000/api/users/me', {
          headers: { Authorization: token }
        });
        setUser(res.data);
      } catch (err) {
        console.error('Failed to load user:', err);
      }
    };

    fetchUser();
  }, []);

  const role = user.role;

  const dashboardItems = {
    coordinator: [
      { label: 'Manage Students', link: '/student' },
      { label: 'Manage Courses', link: '/course' },
      { label: 'Manage Educators', link: '/educator' },
    ],
    educator: [
      { label: 'Study Plans', link: '/plan' },
      { label: 'Quizzes', link: '/quiz' },
      { label: 'Assignments', link: '/assignment' },
      { label: 'Evaluate Learners', link: '/evaluation' },
    ],
    learner: [
      { label: 'View Courses', link: '/courses' },
      { label: 'Study Plans', link: '/study-plans' },
      { label: 'Quizzes', link: '/quizzes' },
      { label: 'Submissions', link: '/submissions' },
    ],
  };

  return (
    <div className="container mt-4">
      <div className="card shadow p-4 mb-4">
        <div className="d-flex align-items-center">
          <img
            src={`http://localhost:5000/uploads/${user.avatar || 'default.png'}`}
            alt="User Avatar"
            className="rounded-circle me-3"
            style={{ width: '60px', height: '60px', objectFit: 'cover' }}
          />
          <div>
            <h4 className="mb-0">Welcome, {user.firstName}!</h4>
            <small className="text-muted">Role: {role}</small>
          </div>
        </div>
      </div>

      <div className="row">
        {(dashboardItems[role] || []).map((item, idx) => (
          <div className="col-md-4 mb-3" key={idx}>
            <div className="card h-100 shadow-sm border-0">
              <div className="card-body d-flex flex-column justify-content-between">
                <h5 className="card-title">{item.label}</h5>
                <a href={item.link} className="btn btn-primary mt-3 w-100">
                  Go →
                </a>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Dashboard;
