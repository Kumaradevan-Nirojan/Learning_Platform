import React, { useEffect, useState } from 'react';
import axios from 'axios';

const StudentPage = () => {
  const [students, setStudents] = useState([]);
  const token = localStorage.getItem('token');

  useEffect(() => {
    const fetchStudents = async () => {
      try {
        const res = await axios.get('http://localhost:5000/api/students', {
          headers: { Authorization: token }
        });
        setStudents(res.data);
      } catch (err) {
        console.error('Error loading students:', err);
      }
    };
    fetchStudents();
  }, []);

  return (
    <div className="container mt-4">
      <h4 className="mb-4">👩‍🎓 Registered Students</h4>
      <div className="table-responsive">
        <table className="table table-bordered table-striped table-hover align-middle">
          <thead className="table-light">
            <tr>
              <th>Name</th>
              <th>Email</th>
              <th>Date of Birth</th>
              <th>Phone</th>
              <th>Country</th>
            </tr>
          </thead>
          <tbody>
            {students.map((stu) => (
              <tr key={stu._id}>
                <td>{stu.firstName} {stu.lastName}</td>
                <td>{stu.email}</td>
                <td>{new Date(stu.dob).toLocaleDateString()}</td>
                <td>{stu.phone}</td>
                <td>{stu.country}</td>
              </tr>
            ))}
            {students.length === 0 && (
              <tr>
                <td colSpan="5" className="text-center text-muted">No students found</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default StudentPage;
